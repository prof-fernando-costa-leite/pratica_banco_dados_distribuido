# Etapa 1 — PostgreSQL: escrita no primário e leitura atrasada na réplica

## Objetivo e previsão

Ao final, demonstre que confirmação da escrita no primário não implica visibilidade imediata na réplica assíncrona. Retome o balanceamento: encaminhar uma leitura para outro servidor só é útil se esse servidor possui os dados e se o contrato de atualização é adequado.

Antes de executar, responda: se a aplicação confirma um cadastro e a consulta seguinte não o encontra, quais duas explicações seriam possíveis? Como distinguir atraso de falha da escrita?

Pré-requisito: [preparação comum](00-PREPARACAO.md). Estimativa: 60–90 minutos após preparar as EC2.

## 1. Suba o primário em A

No terminal da **EC2 A**:

```bash
cd ~/lab-bancos/infra
bash lab.sh pg-a
bash lab.sh status
bash lab.sh inspecionar-pg-a
```

O script inicia PostgreSQL 17.6 na porta 5432. Na primeira inicialização cria `labdb`, a tabela `alunos`, o usuário de CRUD `lab` e o papel `replicador`. O nome do nó é `EC2_A_PRIMARIO`.

Inspecione `pg-init.sh`: identifique onde são criados o papel de replicação e a regra de autenticação para os IPs privados. A replicação é configurada com WAL, que registra as alterações necessárias à recuperação.

Não espere uma réplica na visão `pg_stat_replication` antes da próxima etapa.

## 2. Suba a réplica em B

No terminal da **EC2 B**:

```bash
cd ~/lab-bancos/infra
bash lab.sh pg-b
bash lab.sh status
bash lab.sh inspecionar-pg-b
```

Na primeira execução o script usa `pg_basebackup` para copiar a base do primário, com `-R` para criar a configuração de standby e `-X stream` para incluir o WAL necessário. A réplica atende na porta **5433** e usa `recovery_min_apply_delay=15s`.

O PostgreSQL B deverá mostrar:

- `cluster_name = EC2_B_REPLICA`;
- `pg_is_in_recovery() = true`;
- `recovery_min_apply_delay = 15s`.

Em A, repita:

```bash
bash lab.sh inspecionar-pg-a
```

Agora deve existir uma conexão de replicação em estado `streaming`, com `sync_state = async`.

## Configuração executada pelos scripts

Abra `lab.sh` e localize os blocos `pg-a` e `pg-b`. Os trechos abaixo são para leitura: os scripts já os executaram.

```bash
# No primário: gerar WAL suficiente para replicação e permitir emissores.
postgres -c wal_level=replica -c max_wal_senders=5

# Na réplica: obter a cópia inicial e escrever a configuração de standby.
pg_basebackup -h "$NODE_A" -p 5432 -U replicador -D "$PGDATA" -R -X stream

# Na réplica: atrasar a aplicação dos commits.
postgres -p 5433 -c recovery_min_apply_delay=15s
```

Verifique os arquivos de B, sem exibir o conteúdo de `postgresql.auto.conf`, pois ele pode conter a senha da conexão de replicação:

```bash
sudo docker exec lab-pg-b sh -c 'test -f "$PGDATA/standby.signal" && echo standby.signal-presente'
```

Explique o papel de cada parâmetro antes de prosseguir. A segunda máquina foi clonada a partir do primário; não foi criada como um banco vazio independente para depois receber INSERTs feitos pela aplicação.

## 3. Conecte o cliente no computador local

Execute o binário correspondente ao sistema e escolha **1. PostgreSQL replicado**.

Informe a chave `.pem`; para escrita, IP público e fingerprint de A, porta remota 5432; para leitura, IP público e fingerprint de B, porta remota 5433. Usuário SSH `ubuntu`; banco `labdb`; usuário de banco `lab`; senha de `LAB_PASSWORD` no `.env`.

Escolha **7. Identificar conexões**. O aplicativo consulta o servidor e exibe o nome do nó, sua porta e se está em recuperação. As informações são obtidas do PostgreSQL, não deduzidas apenas do endereço digitado.

## 4. Cadastre e prove o atraso

1. No cliente, escolha cadastrar. Use matrícula `100001`, nome `Ana Souza`, e-mail `ana@example.test`, curso `Computação`.
2. Assim que a escrita for confirmada, busque `100001` no cliente. Faça isso antes de 15 segundos.
3. Na EC2 A, execute `bash lab.sh inspecionar-pg-a`: o aluno já deve estar presente.
4. Na EC2 B, execute `bash lab.sh inspecionar-pg-b`: se ainda estiver dentro da janela, o aluno não estará visível.
5. Após pelo menos 15 segundos desde o commit, consulte novamente no cliente e em B.

O atraso é mínimo em relação ao timestamp do commit no primário, sujeito aos relógios sincronizados e a outros atrasos. Não é um cronômetro exato de 15 segundos desde a mensagem na tela. A consulta direta ao primário é a evidência de que a escrita foi concluída.

Se a operação manual demorar demais, repita com outra matrícula. Prepare os terminais antes do cadastro.

## 5. Repita com UPDATE e DELETE

Atualize o curso para `Engenharia de Software`. Consulte imediatamente pela aplicação: ela pode mostrar o curso antigo. Verifique em A que a atualização já foi aplicada. Depois do atraso, B deverá mostrar o novo curso.

Exclua `100001`, confirmando com a palavra `EXCLUIR`. A exclusão pode ser confirmada enquanto uma leitura pela réplica ainda encontra o aluno. Após a replicação, ele deixa de aparecer.

A mensagem de sucesso da escrita usa o resultado retornado pelo primário; o programa não consulta a réplica para decidir se a escrita ocorreu. Isso evita classificar atraso como falha do cadastro.

## 6. Abra psql em cada nó e consulte manualmente

EC2 A:

```bash
sudo docker exec -it lab-pg-a psql -U postgres -d labdb -p 5432
```

EC2 B:

```bash
sudo docker exec -it lab-pg-b psql -U postgres -d labdb -p 5433
```

Nos dois terminais:

```sql
SELECT current_setting('cluster_name'), pg_is_in_recovery();
SELECT * FROM alunos ORDER BY matricula;
```

A conexão acima usa socket Unix local: `inet_server_addr()` e `inet_server_port()` podem retornar NULL. O nome do nó e `pg_is_in_recovery()` continuam identificando corretamente o serviço. Pela conexão TCP do aplicativo, endereço e porta são retornados.

Em B, tente:

```sql
INSERT INTO alunos VALUES (123456, 'Teste', 'teste@example.test', 'SD');
```

**Resultado esperado:** erro de transação somente leitura. Saia com `\q`. O erro é parte do experimento.

## 7. Interrompa e recupere a réplica

Em B:

```bash
sudo docker stop lab-pg-b
```

No cliente, cadastre outro aluno. A escrita continua possível em A, mas a consulta em B falha. O aplicativo não redireciona silenciosamente a leitura para A.

Recupere B:

```bash
sudo docker start lab-pg-b
bash lab.sh inspecionar-pg-b
```

Volte ao menu de cenários e reconecte, pois o driver PostgreSQL não recria automaticamente a conexão que foi perdida. Aguarde a recuperação e confirme os dados. Nesta atividade curta, o WAL necessário deve continuar disponível; para retenção prolongada, seria necessário projetar slots/arquivamento e monitorar espaço.

## 8. Entrega e interpretação

Entregue evidências de: identificação dos papéis; atraso no cadastro; estado antigo após atualização ou exclusão; recusa de escrita em B; comportamento com B parado.

Explique: por que isso replica dados, mas não divide o armazenamento? Que problema de experiência do usuário aparece após um cadastro? Que mudança permitiria ao usuário ler imediatamente sua própria escrita e qual seria a contrapartida?

## 9. Encerre esta etapa

Em **A e B**:

```bash
bash lab.sh parar pg
```

Os volumes são preservados. Para retomar, execute `pg-a` em A e `pg-b` em B. Não recrie o primário com outro volume mantendo uma réplica antiga. A próxima etapa dividirá os registros entre dois workers.
