# Preparação comum — laboratório de bancos distribuídos

## Resultado esperado

Ao terminar as três etapas, você deverá configurar replicação e fragmentação, executar um CRUD por uma interface lógica e demonstrar, com consultas locais, quais nós armazenam os registros. DNS e balanceamento encaminham pedidos; aqui investigamos o estado persistente que esses pedidos consultam e modificam.

A atividade é individual. Cada ambiente precisa de duas EC2 próprias ou de um par previamente atribuído pelo professor. Não compartilhe bancos entre estudantes sem definir matrículas distintas. Use somente dados fictícios.

## 1. Identifique os componentes

Usaremos as MESMAS duas EC2 em três etapas, ativando uma etapa por vez. As máquinas não equivalem a processos: na etapa Citus, A terá coordenador e worker em processos separados. Na etapa MongoDB, A terá config server, shard e roteador.

O computador local executará apenas `lab-bancos`. Os drivers e o cliente SSH estão incorporados ao executável. Não são necessários Python, Rust, Java, Docker, psql nem mongosh na máquina local. Os comandos administrativos serão executados na EC2, por um terminal SSH existente ou pelo terminal do navegador da AWS.

Os bancos usam protocolos nativos, não HTTP. Não há Nginx nem API REST neste laboratório. As credenciais e a chave são solicitadas a cada sessão e não são gravadas pela aplicação.

## 2. Crie as EC2

No console AWS, crie A e B:

1. Ubuntu Server 24.04 LTS, arquitetura **x86_64/amd64**.
2. Tipo `t3.medium`: 2 vCPU e 4 GiB de memória. Não use T4g/ARM com estes executáveis/imagens sem outra validação.
3. Disco EBS gp3 de 20 GiB por máquina, como ponto de partida para dados pequenos.
4. Mesma VPC e, para simplificar, mesma sub-rede. Acesso de saída à internet para baixar pacotes e imagens.
5. IPv4 público em ambas, para o túnel do cliente. Anote também os IPv4 **privados** de A e B.
6. Crie um par de chaves, formato `.pem` (RSA ou ED25519), e use a mesma chave para A e B. Guarde a chave localmente; não a copie para a EC2 nem para a entrega.
7. Nomeie as instâncias `lab-bancos-A` e `lab-bancos-B`.

O limite de 4 GiB pressupõe somente uma etapa ativa, poucos registros e pouca concorrência. Não é um benchmark de desempenho nem uma topologia de alta disponibilidade.

## 3. Configure o Security Group

Use um grupo dedicado ao laboratório nas duas instâncias:

- TCP 22: origem = IPv4 público/rede de saída autorizada da universidade ou do professor. Confirme que a rede permite SSH de saída.
- Para terminal EC2 Instance Connect no navegador: adicione também a origem exigida pela modalidade/região utilizada, conforme a documentação AWS. Esse acesso não é necessariamente originado do IP do seu navegador.
- TCP 5432–5433: origem = **o próprio Security Group**.
- TCP 5540–5542: origem = **o próprio Security Group**.
- TCP 27017–27020: origem = **o próprio Security Group**.

Não abra as portas de banco para `0.0.0.0/0`. O aplicativo entra pela porta 22 e encaminha a conexão a `127.0.0.1` dentro da EC2. Os nós conversam entre si pelos endereços privados.

A liberação para o próprio grupo vale para máquinas associadas a ele; não reutilize um grupo amplo de outros projetos.

## 4. Abra os terminais e transfira os arquivos

Deixe dois terminais abertos e identificados como A e B. Pelo console AWS: EC2 → instância → Conectar → modalidade disponível. Se houver OpenSSH local, também é possível:

```bash
ssh -i caminho/curso.pem ubuntu@IP_PUBLICO_A
```

Os arquivos serão disponibilizados no [repositório da disciplina](https://github.com/prof-fernando-costa-leite/pratica_banco_dados_distribuido). No terminal de **cada EC2**, baixe o conteúdo da branch padrão do GitHub:

```bash
mkdir -p ~/lab-bancos
cd ~/lab-bancos
curl -fL 'https://github.com/prof-fernando-costa-leite/pratica_banco_dados_distribuido/archive/HEAD.tar.gz' -o laboratorio-github.tar.gz
tar -xzf laboratorio-github.tar.gz --strip-components=1
tar -xzf infra-publica.tar.gz
chmod +x infra/*.sh
test -f infra/lab.sh && echo 'Infraestrutura encontrada'
```

O arquivo `HEAD.tar.gz` acompanha a branch padrão do repositório, sem depender de ela se chamar `main` ou `master`. O repositório contém `Laboratorio_Bancos_Distribuidos_Alunos.zip` e `infra-publica.tar.gz`. A primeira extração obtém esses pacotes; a segunda extrai `infra-publica.tar.gz` e cria a pasta `infra`. O ZIP dos alunos é destinado ao computador local e não precisa ser extraído na EC2. Execute esta etapa de download antes de gerar a configuração do par.

Não é necessário instalar Git no computador local nem nas EC2. Se o download retornar 404, confirme que o professor já publicou o conteúdo e que o repositório está público. Os comandos acima não autenticam em repositórios privados.

Se houver OpenSSH/SCP local, copiar a pasta `infra` manualmente continua sendo uma alternativa. Nos dois casos, o resultado esperado é `~/lab-bancos/infra/lab.sh` em A e B.

O repositório contém somente os arquivos públicos do laboratório. `.env`, `secrets/` e arquivos `.pem` não devem ser publicados; serão gerados ou fornecidos separadamente na preparação.

## 5. Instale Docker SOMENTE nas EC2

Em A e B:

```bash
cd ~/lab-bancos/infra
chmod +x ./*.sh
./instalar-docker-ubuntu.sh
```

O `chmod +x ./*.sh` concede permissão de execução aos scripts. Faça isso nas duas EC2, inclusive se transferiu os arquivos por SCP. Com essa permissão, você pode executar `./lab.sh`; os comandos `bash lab.sh` usados nos roteiros também funcionam, pois chamam o interpretador diretamente.

Usamos contêineres para fixar versões e separar os processos, mas configuraremos explicitamente replicação, nós e fragmentos. O roteiro não pede instalar nada nos computadores da universidade.

## 6. Gere e compartilhe a configuração do par

Em A:

```bash
cd ~/lab-bancos/infra
bash configurar.sh
```

Informe os IPs **privados** de A e B. O script gera uma senha aleatória e a chave interna do MongoDB. Os arquivos `infra/.env` e `infra/secrets/mongo-key` devem ser **idênticos** nas duas EC2.

A transferência precisa levar **dois arquivos: `.env` e `secrets/mongo-key`**. Copiar apenas o texto de `.env` não é suficiente. Pelos terminais do navegador, siga exatamente esta ordem.

### 6.1. Na EC2 A: gere o bloco Base64

```bash
cd ~/lab-bancos/infra
tar -czf - .env secrets | base64 -w0
printf '\n'
```

Esse comando empacota os arquivos e transforma o pacote em uma sequência longa de caracteres. **Copie somente a sequência produzida**, sem os comandos e sem o prompt `ubuntu@...`. O `printf` apenas separa a saída do próximo prompt.

**Não copie o conteúdo que aparece ao abrir `.env`.** Linhas como `NODE_A=...`, `NODE_B=...` ou `LAB_PASSWORD=...` são texto de configuração, não o bloco Base64 esperado. A sequência correta não começa com `NODE_A=`.

### 6.2. Na EC2 B: decodifique e extraia o bloco

```bash
cd ~/lab-bancos/infra
umask 077
base64 -d <<'BLOCO' | tar -xzf -
COLE_AQUI_A_SEQUENCIA_GERADA_EM_A
BLOCO
```

Substitua a linha `COLE_AQUI_A_SEQUENCIA_GERADA_EM_A` pela sequência copiada de A. Não digite essa frase literalmente. A última linha deve conter **apenas `BLOCO`**, sem aspas ou espaços antes/depois. O terminal pode exibir um prompt de continuação enquanto espera essa última linha; isso é normal.

### 6.3. Ainda na EC2 B: confirme os arquivos

```bash
test -s .env && echo '.env encontrado'
test -s secrets/mongo-key && echo 'Chave MongoDB encontrada'
```

Devem aparecer as duas mensagens. Para conferir que o conteúdo é idêntico, execute **em A e em B**:

```bash
cd ~/lab-bancos/infra
sha256sum .env secrets/mongo-key
```

Compare os hashes de cada arquivo entre as máquinas: o hash de `.env` em A deve ser igual ao de `.env` em B, e o mesmo vale para a chave. A simples presença dos arquivos não comprova que sejam idênticos.

Se aparecer `base64: invalid input` e `gzip: stdin: not in gzip format`, a sequência colada não era um bloco válido ou foi copiada incompletamente. Volte ao passo 6.1, gere o bloco e copie novamente. Não prossiga até conferir os arquivos e seus hashes.

Esse bloco contém segredos. Não inclua em capturas, relatórios, repositórios ou mensagens públicas. Limpe o clipboard depois. **Não execute `configurar.sh` em B para gerar outra chave.**

Para consultar a senha do aplicativo privadamente, abra `.env` no terminal remoto (`nano .env`). O usuário de CRUD será `lab` e o banco `labdb` nas três etapas. `labadmin` é reservado à administração MongoDB dos scripts.

## 7. Obtenha a identidade SSH dos servidores

No terminal AWS de A e no de B:

```bash
sudo ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub -E sha256
```

Anote o trecho `SHA256:...`. É a impressão digital da chave **do servidor**, não a chave `.pem` do aluno. O aplicativo exigirá esse valor e recusará uma chave diferente. Se a EC2 for recriada, confira novamente pelo console AWS antes de usar a nova impressão digital.

## 8. Execute o cliente local

**Agora trabalhe no computador local, não no terminal da EC2.** Baixe `Laboratorio_Bancos_Distribuidos_Alunos.zip` do repositório, extraia e abra a pasta **`lab-bancos/dist`**. Ali estão os dois executáveis Rust já compilados. O pacote `infra-publica.tar.gz` usado nas EC2 não contém a aplicação.

Você pode abrir o programa e ver o menu antes de configurar os bancos; para conectar e executar o CRUD, conclua também os passos da etapa correspondente nas EC2. Não é necessário instalar Rust nem compilar.

Windows x86_64, PowerShell na pasta dos executáveis:

```powershell
.\lab-bancos-windows-x86_64.exe
```

Linux x86_64:

```bash
chmod +x lab-bancos-linux-x86_64
./lab-bancos-linux-x86_64
```

O executável Linux é estático. No Windows não é necessário instalar um runtime Rust. Uma política institucional pode impedir executar arquivos baixados; teste previamente com a TI, sem desativar controles da instituição.

O cliente solicita cenário, caminho da chave, frase secreta opcional, IP público, usuário SSH `ubuntu`, impressão digital e porta remota. Depois pede banco `labdb`, usuário `lab` e senha. Na etapa 1 pede A e B; nas outras, apenas A.

As portas locais do túnel são escolhidas automaticamente. Não informe o IP privado na pergunta do endereço público. A porta solicitada é a do serviço **na EC2**, não a porta 22 do SSH.

## 9. Critério de evidência

Cada experimento deve registrar: previsão; operação no cliente; identificação do nó no terminal remoto; registros encontrados; explicação do resultado. Nunca capture senha ou chave. Uma listagem no cliente prova a visão lógica; uma consulta local no worker/shard prova a localização física.

Ao encerrar uma etapa, use os comandos `parar` do roteiro nas duas máquinas. Eles removem os contêineres, preservando os volumes de dados. A conclusão do laboratório exige também interromper/encerrar as EC2 pelo console AWS, conforme orientação do professor.
