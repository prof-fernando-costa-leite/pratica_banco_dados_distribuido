# Etapa 2 — PostgreSQL + Citus: uma tabela lógica, fragmentos em dois workers

## Objetivo e previsão

Demonstre que o cliente consulta uma tabela única, embora seus registros estejam em fragmentos físicos diferentes. Compare com a etapa anterior: uma réplica guarda uma cópia; um worker guarda fragmentos atribuídos a ele.

Pré-requisito: preparação comum; etapa 1 encerrada nas duas EC2. Estimativa: 60–90 minutos.

Nossa topologia tem três processos: coordenador em A:5540, worker A:5541 e worker B:5542. Não é primário/réplica. Não configuramos redundância dos fragmentos; a perda de um worker pode impedir consultas que dependem dele.

## Antes de iniciar: libere o intervalo completo do Citus

No console AWS, abra **EC2 → Instâncias → EC2 B → Segurança → Security Group → Editar regras de entrada → Adicionar regra**. Escolha **TCP personalizado** e digite exatamente **`5540-5542`** no campo **Intervalo de portas**, com hífen comum. Na origem **Personalizado**, selecione o ID `sg-...` do Security Group de A e salve.

Se os grupos forem distintos, adicione também a mesma regra no grupo de A, com origem no grupo de B. Se A e B compartilham um grupo, basta a regra nesse grupo com origem nele próprio. Confira as regras salvas, não apenas os campos antes de salvar. Se as saídas estiverem restritas, permita também o tráfego para o outro nó nessas portas.

**Não informe apenas `5540`.** As portas são 5540 (coordenador em A), 5541 (worker A) e 5542 (worker B). A regra PostgreSQL/5432 da etapa anterior não libera nenhuma dessas portas.

## 1. Inicie os processos

EC2 A:

```bash
cd ~/lab-bancos/infra
bash lab.sh citus-a
bash lab.sh status
```

EC2 B:

```bash
cd ~/lab-bancos/infra
bash lab.sh citus-b
bash lab.sh status
```

O contêiner de cada nó usa PostgreSQL com a extensão Citus. Os processos em A usam portas e volumes distintos. As versões do PostgreSQL neste ambiente e no ambiente de replicação não precisam ser idênticas: são bancos independentes e não replicam dados entre si.

### Confirme a comunicação antes de cadastrar os workers

Com os processos de A e B iniciados, execute **na EC2 A**:

```bash
cd ~/lab-bancos/infra
source .env
timeout 5 bash -c 'echo > /dev/tcp/$1/5542' _ "$NODE_B" \
  && echo 'Worker B acessível' \
  || echo 'Sem conexão com o worker B: revise as regras de rede'
```

Execute **na EC2 B** para verificar o caminho de volta aos serviços de A:

```bash
cd ~/lab-bancos/infra
source .env
for porta in 5540 5541; do
  timeout 5 bash -c 'echo > /dev/tcp/$1/$2' _ "$NODE_A" "$porta" \
    && echo "A:$porta acessível" \
    || echo "Sem conexão com A:$porta: revise as regras de rede"
done
```

**Só execute `citus-init` quando os três testes indicarem acesso.** Se um teste falhar, confira a regra de entrada no grupo da máquina de destino e o intervalo completo `5540-5542`. Um processo `running` ou uma porta `LISTEN` no próprio servidor não comprova acesso pela outra EC2.

Para verificar a escuta do worker B, execute em B:

```bash
sudo ss -lntp 'sport = :5542'
```

A escuta deve incluir o IP privado de B. Se isso estiver correto, mas o teste em A falhar, revise a rede, começando pelo Security Group. Recriar o contêiner não libera a porta.

## 2. Cadastre os workers e distribua a tabela

Depois de A e B estarem prontos, **em A, uma única vez**:

```bash
bash lab.sh citus-init
```

Leia o bloco `citus-init` em `lab.sh`. As operações centrais são:

```sql
SELECT citus_set_coordinator_host('IP_PRIVADO_A', 5540);
SELECT citus_add_node('IP_PRIVADO_A', 5541);
SELECT citus_add_node('IP_PRIVADO_B', 5542);
SET citus.shard_count = 4;
SELECT create_distributed_table('alunos', 'matricula');
```

O script substitui os IPs pelo `.env`. A matrícula é a chave de distribuição. Citus aplica uma função hash para determinar o fragmento; não conclua que matrículas menores sempre vão para A. Os quatro fragmentos devem ter posições nos dois workers.

Se `citus-init` falhou ao conectar a B, antes de executar `create_distributed_table`, corrija a rede, repita os testes e então repita `citus-init`. Se a distribuição já foi concluída, apenas inspecione: não repita a inicialização.

O comando de distribuição não é uma rotina para executar a cada reinício. Se já existir a tabela distribuída, inspecione em vez de inicializar novamente.

## 3. Conecte o aplicativo e carregue registros

Escolha **2. PostgreSQL + Citus**. Informe IP público e fingerprint de A, porta remota **5540**, banco `labdb`, usuário `lab`, senha do `.env`.

Escolha **6. Inserir 20 exemplos** e confirme `s`. O conjunto possui matrículas `100001..100010` e `700001..700010`, todas inteiras. Depois liste os alunos. A listagem está limitada a 100 registros para manter a tela legível.

O cliente exibe `EC2_A_COORDENADOR`. **Isso identifica quem respondeu ao protocolo, não prova que os registros estão armazenados no coordenador.**

## 4. Inspecione a visão lógica e os metadados

Em A:

```bash
bash lab.sh inspecionar-citus
```

A saída mostra a tabela lógica completa e `citus_shards`: identificador do fragmento, nome da tabela física, endereço e porta do worker.

No cliente, escolha **8. Localizar fragmento / explicar consulta** e informe uma matrícula existente. O programa consulta `get_shard_id_for_distribution_column` e mostra o worker responsável.

Anote a localização prevista para duas matrículas. Caso ambas caiam no mesmo worker, escolha outras com base nos registros listados na próxima etapa.

## 5. Prove onde os registros estão fisicamente

Em A:

```bash
bash lab.sh inspecionar-worker-a
```

Em B:

```bash
bash lab.sh inspecionar-worker-b
```

Os comandos conectam diretamente aos workers, identificam o nó e consultam as tabelas físicas `public.alunos_<id_do_fragmento>`.

Não use apenas `SELECT * FROM alunos` no worker como prova da distribuição: a inspeção que interessa é a das tabelas de fragmentos. Uma tabela lógica pode existir como parte dos metadados do Citus; a prova do armazenamento está nos fragmentos físicos identificados pelo catálogo.

Para investigar manualmente, em B:

```bash
sudo docker exec -it lab-citus-wb psql -U postgres -d labdb -p 5542
```

No psql:

```sql
SELECT current_setting('cluster_name');
SET citus.show_shards_for_app_name_prefixes='psql';
SELECT schemaname, tablename
FROM pg_tables
WHERE schemaname='public' AND tablename ~ '^alunos_[0-9]+$';
```

O Citus oculta fragmentos de algumas consultas ao catálogo por padrão. O `SET` acima habilita a visibilidade para esta sessão psql; não altera a distribuição nem cria dados.

Copie um nome retornado e consulte, substituindo o exemplo:

```sql
SELECT * FROM public.alunos_XXXXXX ORDER BY matricula;
```

Os IDs são gerados pelo Citus; não suponha um número fixo. Saia com `\q`.

**Verificação:** a união dos registros físicos dos workers corresponde ao conjunto listado pelo coordenador. Cada matrícula deve ocorrer uma vez neste ambiente sem réplicas de shard.

## 6. Atualize um aluno e confira o worker

Localize uma matrícula com a opção 8, altere o curso no CRUD e consulte diretamente o fragmento responsável. Repita com exclusão. A aplicação continua usando uma única conexão lógica, e o Citus localiza o worker.

A matrícula não é editável no cliente: mudar a chave de distribuição introduziria outra operação de redistribuição que não é necessária neste CRUD.

## 7. Experimento de falha parcial

Antes de parar qualquer coisa, identifique uma matrícula em A e uma em B. Em B:

```bash
sudo docker stop lab-citus-wb
```

No cliente:

1. Busque a matrícula de B: a consulta deverá falhar.
2. Busque a matrícula de A: uma consulta roteada apenas a A pode continuar funcionando.
3. Liste todos os alunos: a consulta que precisa dos dois workers deverá falhar, em vez de produzir silenciosamente uma listagem completa falsa.

Recupere:

```bash
sudo docker start lab-citus-wb
```

Reconecte o cliente se necessário e repita as consultas. Compare com a etapa 1: aqui não há outra cópia do fragmento de B pronta para substituí-lo.

## 8. Entrega e encerramento

Entregue: quatro fragmentos e suas posições; registros físicos em ambos os workers; localização de duas matrículas; atualização no worker correto; resultados da falha parcial.

Responda: quatro shards significam quatro máquinas? O coordenador guardar metadados significa guardar todos os alunos? Por que mais workers não garante escala linear?

Em A e B:

```bash
bash lab.sh parar citus
```

Para retomar, reinicie com `citus-a` e `citus-b`, preservando volumes. Não execute `citus-init` novamente. Na próxima etapa, compare esse mecanismo com sharding integrado ao MongoDB.
