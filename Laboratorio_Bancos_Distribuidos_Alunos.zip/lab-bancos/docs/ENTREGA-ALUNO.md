# Registro de experimentos do aluno

Nome: ____________________  Data: ____________________

Não inclua senhas, chaves privadas, conteúdo de `.env` ou o bloco de transferência de segredos.

## Etapa 1 — replicação

1. Identifique primário e réplica com saídas de `cluster_name` e `pg_is_in_recovery()`.
2. Registre uma matrícula, horário aproximado do commit e primeira leitura que a encontrou na réplica.
3. Compare o registro no primário e na réplica durante a janela de atraso.
4. Mostre um UPDATE ou DELETE cujo efeito demorou a aparecer na leitura.
5. Mostre a recusa de escrita na réplica e explique o comportamento com B parado.

Para cada experimento: previsão → comando/operação → saída observada → interpretação.

## Etapa 2 — Citus

1. Liste os quatro fragmentos e os workers que os armazenam.
2. Identifique uma matrícula em A e uma em B, com consulta física nos fragmentos.
3. Compare a soma dos registros físicos com a consulta lógica.
4. Mostre uma alteração feita pela aplicação no worker correto.
5. Compare busca direcionada e listagem global com B parado.

Explique por que esta etapa não é outra configuração de primário/réplica.

## Etapa 3 — MongoDB

1. Identifique mongos, config server e os dois shards.
2. Mostre os intervalos e o corte em 500000.
3. Mostre documentos de matrículas baixas somente em A e altas somente em B.
4. Relacione o explain de uma busca ao shard que contém o documento.
5. Compare consultas com e sem chave de distribuição e repita sob falha de B.

Explique o papel de um replica set dentro de um cluster fragmentado e a limitação de um único membro por shard.

## Comparação final

Em um texto curto, responda: o que cada etapa distribui? Quem escolhe o nó? Que estados temporariamente divergentes ou indisponibilidades foram observados? O que precisaria mudar para tolerar a falha de uma máquina sem perder acesso a uma parte dos dados?
