# Fontes técnicas

Consulta: 22 de setembro de 2026. As imagens e o lockfile do pacote fixam versões para a reprodução do laboratório; links `current`, `manual` e `latest` podem evoluir.

- [PostgreSQL — standby e streaming replication](https://www.postgresql.org/docs/17/warm-standby.html): primário, réplica e WAL.
- [PostgreSQL — recovery_min_apply_delay](https://www.postgresql.org/docs/current/runtime-config-replication.html#GUC-RECOVERY-MIN-APPLY-DELAY): atraso na aplicação de commits, relógios e interação com remote_apply.
- [Citus 13 — criação de tabelas distribuídas](https://docs.citusdata.com/en/v13.0/develop/reference_ddl.html): chave de distribuição e fragmentos.
- [Citus 13 — catálogos e visões](https://docs.citusdata.com/en/v13.0/develop/api_metadata.html): localização dos shards.
- [Citus — projeto oficial](https://github.com/citusdata/citus): extensão PostgreSQL e arquitetura coordenador/workers.
- [MongoDB 8.0 — implantação de cluster fragmentado](https://www.mongodb.com/docs/v8.0/tutorial/deploy-shard-cluster/): config servers, shards e mongos.
- [MongoDB — sharding](https://www.mongodb.com/docs/manual/sharding/): distribuição e roteamento.
- [MongoDB — referência de sharding](https://www.mongodb.com/docs/manual/reference/sharding/): splitAt, moveChunk e inspeção.
- [MongoDB — diagnóstico e memória](https://www.mongodb.com/docs/manual/faq/diagnostics/): cache WiredTiger e memória total.
- [AWS — T3](https://aws.amazon.com/ec2/instance-types/t3/): especificações de memória e CPU.
- [AWS — pré-requisitos de EC2 Instance Connect](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-instance-connect-prerequisites.html): conectividade e permissões.
- [Docker — instalação em Ubuntu](https://docs.docker.com/engine/install/ubuntu/): repositório oficial e pacotes.
- [Russh](https://github.com/Eugeny/russh): cliente SSH incorporado.
- [MongoDB — driver Rust](https://www.mongodb.com/docs/drivers/rust/current/): acesso ao MongoDB pelo aplicativo.

O material foi alinhado às notas locais `output/bancos_distribuidos_v3/Notas_de_Aula_Bancos_Distribuidos.md`, que retomam DNS, balanceamento e CDN e distinguem replicação de fragmentação.
