# Etapa 3 — MongoDB: coleção única, documentos em dois shards

## Objetivo e previsão

Configure sharding e relacione a chave de um documento ao nó que o armazena. Compare com o Citus: ambos oferecem um ponto lógico de acesso e distribuição física; diferem em configuração, metadados, comandos e modelo de dados. Não conclua facilidade ou desempenho apenas pela quantidade de linhas de um script.

Pré-requisito: preparação comum; etapas PostgreSQL encerradas nas duas máquinas. Estimativa: 90–120 minutos.

## 1. Identifique os papéis

- EC2 A: shard `sa`, porta 27018; config server `cfg`, porta 27019; roteador `mongos`, porta 27017.
- EC2 B: shard `sb`, porta 27020.
- Aplicativo local: conexão somente ao `mongos` em A.

Cada shard é um replica set de **um membro**. O config server também tem um membro. Isso reduz recursos no laboratório, mas não oferece tolerância à perda de um membro. São quatro processos em duas máquinas, não dois processos nem um único replica set.

## 2. Inicie config server e shards

Em A:

```bash
cd ~/lab-bancos/infra
bash lab.sh mongo-a
bash lab.sh status
```

Em B:

```bash
cd ~/lab-bancos/infra
bash lab.sh mongo-b
bash lab.sh status
```

Os serviços usam a mesma chave interna `secrets/mongo-key`. Os scripts copiam essa chave para dentro do contêiner com permissões restritas. Ela autentica a comunicação entre componentes; não é a chave SSH da EC2.

## 3. Inicialize os replica sets e usuários administrativos

Aguarde os processos iniciarem. Em A, **uma única vez**:

```bash
bash lab.sh mongo-init-a
```

Em B, **uma única vez**:

```bash
bash lab.sh mongo-init-b
```

O script executa `rs.initiate`, aguarda o membro tornar-se primário e cria o usuário administrativo. O primeiro acesso usa a exceção de localhost para criar o primeiro usuário; ela deixa de permitir esse bootstrap depois que o usuário existe.

A configuração de cada membro usa o endereço **privado** real da EC2 e a porta correspondente. Os nós devem conseguir alcançar esses endereços.

Se receber “usuário já existe” ou “Unauthorized” ao repetir esse passo, não apague dados: ele é de inicialização, não de reinício. Use os comandos de inspeção autenticados para verificar o estado.

## 4. Inicie o roteador

Em A:

```bash
bash lab.sh mongo-router
```

O argumento `--configdb cfg/IP_PRIVADO_A:27019` informa onde estão os metadados. Depois:

```bash
bash lab.sh mongo-init
```

Esse comando também é executado **uma única vez** por ambiente novo. Ele:

1. Registra os shards `sa` e `sb` no cluster.
2. Desliga o balanceador automático para deixar a demonstração determinística.
3. Cria `labdb.alunos` com índice único em `matricula`.
4. Habilita sharding pela chave `{matricula: 1}`.
5. Divide os intervalos no valor inteiro `500000`.
6. Move o intervalo que contém `700001` para `sb`.
7. Cria o usuário `lab` com acesso de leitura/escrita em `labdb`.

Neste laboratório usamos fragmentação por **faixas**, não hash. Portanto:

- matrículas menores que 500000 pertencem ao shard A (`sa`);
- matrículas maiores ou iguais a 500000 pertencem ao shard B (`sb`).

O aplicativo armazena matrícula como inteiro BSON de 64 bits. Nos comandos mongosh use `Long('100001')`, e não a string `'100001'` como valor da chave.

## Comandos de configuração para analisar

Abra `lab.sh` e relacione os blocos `mongo-init-a`, `mongo-init-b` e `mongo-init` com estes trechos conceituais. Eles já foram executados pelos scripts; não os repita no ambiente inicializado.

```javascript
// Um replica set mínimo por shard; executado no respectivo mongod.
rs.initiate({_id:'sa', members:[{_id:0, host:'IP_PRIVADO_A:27018'}]})
rs.initiate({_id:'sb', members:[{_id:0, host:'IP_PRIVADO_B:27020'}]})

// Executado no mongos autenticado.
sh.addShard('sa/IP_PRIVADO_A:27018')
sh.addShard('sb/IP_PRIVADO_B:27020')
sh.enableSharding('labdb','sa')
sh.shardCollection('labdb.alunos',{matricula:1},true)
sh.splitAt('labdb.alunos',{matricula:Long('500000')})
sh.moveChunk('labdb.alunos',{matricula:Long('700001')},'sb')
```

O primeiro conjunto define os participantes de cada replica set; o segundo associa esses conjuntos ao cluster fragmentado e define a distribuição dos dados. A configuração do config server usa `configsvr:true` e replica set `cfg`, conforme o script.

## 5. Conecte o cliente local

Escolha **3. MongoDB com sharding**. Informe chave e IP público/fingerprint de A, porta remota **27017**, banco `labdb`, usuário `lab`, senha do `.env`.

O cliente verifica `hello` e exige `msg = isdbgrid`, identificando que chegou ao `mongos`. Não use a porta do shard no cliente: isso contornaria a interface lógica que queremos demonstrar.

Escolha inserir os 20 exemplos e depois listar. O conjunto lógico deve conter tanto os alunos `100001..100010` quanto `700001..700010`.

## 6. Inspecione o roteador e os nós

Em A, visão lógica e metadados:

```bash
bash lab.sh inspecionar-mongo
```

Em A, visão física do shard A:

```bash
bash lab.sh inspecionar-shard-a
```

Em B, visão física do shard B:

```bash
bash lab.sh inspecionar-shard-b
```

Verifique o campo `setName` em `hello`: `sa` ou `sb`. O roteador retorna `isdbgrid`. No shard A devem aparecer os dez alunos com matrículas baixas; no B, os dez de matrículas altas.

Em um sistema que movimenta chunks com dados, cópias temporárias órfãs podem existir até a limpeza. Aqui os intervalos foram posicionados antes da inserção e o balanceador foi parado, para simplificar a interpretação das consultas diretas. Não transforme essa simplificação em regra geral de produção.

## 7. Abra mongosh manualmente

Na EC2 A, dentro de `infra`:

```bash
set -a
source .env
set +a
sudo docker exec -it lab-mongo-sa mongosh --port 27018 -u "$MONGO_USER" --authenticationDatabase admin
```

Digite a senha administrativa quando solicitada. No shell:

```javascript
db.hello()
use labdb
db.alunos.find().sort({matricula:1})
db.alunos.findOne({matricula:Long('100001')})
db.alunos.findOne({matricula:Long('700001')})
```

O último resultado deve ser `null` no shard A. Repita em B usando contêiner `lab-mongo-sb` e porta 27020; o comportamento se inverte. Saia com `exit`.

Acesse o roteador em A trocando para contêiner `lab-mongo-router`, porta 27017. Ambos os documentos deverão ser encontrados por ele.

Use as conexões diretas aos shards apenas para leitura/inspeção neste laboratório. Faça as escritas pelo roteador.

## 8. Explique o roteamento

No cliente, opção **8**, procure `100001` e depois `700001`. O cliente resume o `explain`, mostrando o tipo de plano, o nome do shard e seu endereço. O plano completo pode ser examinado no mongosh com os comandos abaixo.

No mongosh do roteador:

```javascript
use labdb
db.alunos.find({matricula:Long('100001')}).explain('executionStats')
db.alunos.find({curso:'Sistemas Distribuídos'}).explain('executionStats')
```

Compare uma busca que informa a chave de distribuição com outra que não a informa. A primeira pode ser direcionada a um shard; a segunda pode precisar consultar ambos.

## 9. Atualização, exclusão e falha parcial

Atualize e exclua um aluno de cada faixa no aplicativo. Confirme a alteração diretamente no shard responsável.

Em B:

```bash
sudo docker stop lab-mongo-sb
```

Compare busca de `100001`, busca de `700001` e listagem completa. A consulta direcionada ao shard saudável pode funcionar; a operação que precisa do shard indisponível deve apresentar erro/timeout. Não solicitamos resultados parciais como se fossem completos.

Recupere:

```bash
sudo docker start lab-mongo-sb
```

Aguarde o replica set voltar a ter primário e repita. Se necessário, troque o cenário no cliente e reconecte. A recuperação não significa eleição de outro membro: cada shard só possui um membro, que voltou a funcionar.

## 10. Entrega e encerramento

Entregue: identificação dos quatro papéis; visão lógica com vinte alunos; dez documentos em cada shard antes das alterações; explain de duas consultas; atualização no shard correto; comportamento na falha.

Responda: por que replica set e sharding são conceitos diferentes? Por que a escolha da chave influencia consultas e concentração de carga? Quais componentes adicionais seriam necessários para tolerar falha de uma máquina?

Em A e B:

```bash
bash lab.sh parar mongo
```

Para retomar com os volumes existentes: `mongo-a` em A, `mongo-b` em B e depois `mongo-router` em A. Não repita os comandos `mongo-init*`. Ao concluir o laboratório, siga também o encerramento das EC2 e recursos AWS previsto pelo professor.
