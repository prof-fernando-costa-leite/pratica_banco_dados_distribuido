#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[[ -f .env ]] || { echo 'Execute configurar.sh em A e copie .env e secrets para B.'; exit 1; }
set -a; source .env; set +a
if docker info >/dev/null 2>&1; then D=(docker); else D=(sudo docker); fi
run() { "${D[@]}" "$@"; }
ROOT=$PWD
pg() { run exec -i "$1" psql -X -U postgres -d labdb -v ON_ERROR_STOP=1 "${@:2}"; }
mongo() { run exec -i "$1" mongosh --quiet --port "$2" -u "$MONGO_USER" -p "$MONGO_PASSWORD" --authenticationDatabase admin "${@:3}"; }
waitpg() { for i in {1..60}; do run exec "$1" pg_isready -U postgres -p "$2" >/dev/null 2>&1 && return; sleep 2; done; echo "Timeout: $1"; exit 1; }
startpg() {
  local name=$1 port=$2 image=$3 label=$4
  local create_table=1
  [[ $label == *_WORKER ]] && create_table=0
  run run -d --name "$name" --network host --memory 640m --env-file .env \
    -e PGPASSFILE=/var/lib/postgresql/data/lab.pgpass -e LAB_CREATE_TABLE="$create_table" -v "$name-data:/var/lib/postgresql/data" \
    -v "$ROOT/pg-init.sh:/docker-entrypoint-initdb.d/10-lab.sh:ro" \
    "$image" postgres -p "$port" -c "cluster_name=$label" -c shared_buffers=64MB \
    -c work_mem=2MB -c max_connections=40 -c "listen_addresses=127.0.0.1,$5" \
    -c wal_level=replica -c max_wal_senders=5
  waitpg "$name" "$port"
}
waitmongo() {
  for i in {1..60}; do
    run exec "$1" mongosh --quiet --port "$2" --eval "db.adminCommand({ping:1})" >/dev/null 2>&1 && return
    sleep 2
  done
  echo "Timeout: $1"; exit 1
}
startmongo() {
  local name=$1 port=$2 rs=$3 role=$4 bind=$5
  # Copiamos para dentro do contêiner para ter owner/permissão corretos sem chmod no host.
  run run -d --name "$name" --network host --memory 768m --env-file .env \
    -v "$name-data:/data/db" -v "$ROOT/secrets/mongo-key:/run/lab-key:ro" \
    --entrypoint bash "$MONGO_IMAGE" -c '
      cp /run/lab-key /tmp/mongo-key; chown mongodb:mongodb /tmp/mongo-key; chmod 400 /tmp/mongo-key
      exec gosu mongodb mongod --dbpath /data/db --port "$1" --replSet "$2" "$3" --bind_ip "$4" --keyFile /tmp/mongo-key --wiredTigerCacheSizeGB 0.256
    ' -- "$port" "$rs" "$role" "127.0.0.1,$bind"
  waitmongo "$name" "$port"
}
initmongo() {
  local name=$1 port=$2 rs=$3 host=$4 cfg=$5
  run exec -i "$name" mongosh --quiet --port "$port" --eval "
    const config={_id:'$rs',members:[{_id:0,host:'$host:$port'}]};
    if ('$cfg' === 'yes') config.configsvr=true;
    try { rs.status(); } catch(e) { if(e.code===94) rs.initiate(config); else throw e; }
    let ready=false; for(let i=0;i<60;i++){if(db.hello().isWritablePrimary){ready=true;break;} sleep(1000);}
    if(!ready) throw Error('Sem primário');
    db.getSiblingDB('admin').createUser({user:process.env.MONGO_USER,pwd:process.env.MONGO_PASSWORD,roles:['root']});
  "
}
case "${1:-}" in
  pg-a) startpg lab-pg-a 5432 "$PG_IMAGE" EC2_A_PRIMARIO "$NODE_A" ;;
  pg-b)
    run run -d --name lab-pg-b --network host --memory 640m --env-file .env \
      -v lab-pg-b-data:/var/lib/postgresql/data --entrypoint bash "$PG_IMAGE" -c '
      set -e
      install -d -o postgres -g postgres -m 700 "$PGDATA"
      if [ ! -s "$PGDATA/PG_VERSION" ]; then
        export PGPASSWORD="$LAB_PASSWORD"
        gosu postgres pg_basebackup -h "$NODE_A" -p 5432 -U replicador -D "$PGDATA" -R -X stream
      fi
      exec gosu postgres postgres -p 5433 -c cluster_name=EC2_B_REPLICA -c "listen_addresses=127.0.0.1,$NODE_B" -c recovery_min_apply_delay=15s -c shared_buffers=64MB -c max_connections=40
    '
    waitpg lab-pg-b 5433 ;;
  citus-a)
    startpg lab-citus-wa 5541 "$CITUS_IMAGE" EC2_A_WORKER "$NODE_A"
    startpg lab-citus-coord 5540 "$CITUS_IMAGE" EC2_A_COORDENADOR "$NODE_A" ;;
  citus-b) startpg lab-citus-wb 5542 "$CITUS_IMAGE" EC2_B_WORKER "$NODE_B" ;;
  citus-init)
    pg lab-citus-coord -p 5540 --set=a="$NODE_A" --set=b="$NODE_B" <<'SQL'
CREATE EXTENSION IF NOT EXISTS citus;
SELECT citus_set_coordinator_host(:'a', 5540);
SELECT citus_add_node(:'a', 5541);
SELECT citus_add_node(:'b', 5542);
SET citus.shard_count = 4;
SELECT create_distributed_table('alunos', 'matricula');
SELECT shardid, nodename, nodeport FROM citus_shards WHERE table_name='alunos'::regclass ORDER BY shardid;
SQL
    ;;
  mongo-a)
    startmongo lab-mongo-config 27019 cfg --configsvr "$NODE_A"
    startmongo lab-mongo-sa 27018 sa --shardsvr "$NODE_A" ;;
  mongo-b) startmongo lab-mongo-sb 27020 sb --shardsvr "$NODE_B" ;;
  mongo-init-a)
    initmongo lab-mongo-config 27019 cfg "$NODE_A" yes
    initmongo lab-mongo-sa 27018 sa "$NODE_A" no ;;
  mongo-init-b) initmongo lab-mongo-sb 27020 sb "$NODE_B" no ;;
  mongo-router)
    run run -d --name lab-mongo-router --network host --memory 384m --env-file .env \
      -v "$ROOT/secrets/mongo-key:/run/lab-key:ro" --entrypoint bash "$MONGO_IMAGE" -c '
      cp /run/lab-key /tmp/mongo-key; chown mongodb:mongodb /tmp/mongo-key; chmod 400 /tmp/mongo-key
      exec gosu mongodb mongos --configdb "cfg/$NODE_A:27019" --port 27017 --bind_ip "127.0.0.1,$NODE_A" --keyFile /tmp/mongo-key
    '
    waitmongo lab-mongo-router 27017 ;;
  mongo-init)
    mongo lab-mongo-router 27017 --eval "
      sh.addShard('sa/$NODE_A:27018'); sh.addShard('sb/$NODE_B:27020');
      sh.stopBalancer();
      sh.enableSharding('labdb','sa');
      const d=db.getSiblingDB('labdb');
      d.createCollection('alunos'); d.alunos.createIndex({matricula:1},{unique:true});
      sh.shardCollection('labdb.alunos',{matricula:1},true);
      sh.splitAt('labdb.alunos',{matricula:Long('500000')});
      sh.moveChunk('labdb.alunos',{matricula:Long('700001')},'sb');
      d.createUser({user:'lab',pwd:process.env.LAB_PASSWORD,roles:[{role:'readWrite',db:'labdb'}]});
      sh.status();
    " ;;
  inspecionar-pg-a) pg lab-pg-a -p 5432 -c "SELECT current_setting('cluster_name') AS no, pg_is_in_recovery() AS replica, inet_server_port(); TABLE alunos; SELECT application_name,client_addr,state,sync_state,replay_lag FROM pg_stat_replication;" ;;
  inspecionar-pg-b) pg lab-pg-b -p 5433 -c "SELECT current_setting('cluster_name') AS no, pg_is_in_recovery() AS replica; SHOW recovery_min_apply_delay; TABLE alunos; SELECT pg_last_wal_receive_lsn(), pg_last_wal_replay_lsn(), pg_last_xact_replay_timestamp();" ;;
  inspecionar-citus)
    pg lab-citus-coord -p 5540 -c "SELECT current_setting('cluster_name'); TABLE alunos; SELECT shardid,shard_name,nodename,nodeport FROM citus_shards WHERE table_name='alunos'::regclass ORDER BY shardid;" ;;
  inspecionar-worker-a|inspecionar-worker-b)
    if [[ $1 == *-a ]]; then name=lab-citus-wa; port=5541; else name=lab-citus-wb; port=5542; fi
    pg "$name" -p "$port" <<'SQL'
SELECT current_setting('cluster_name');
SET citus.show_shards_for_app_name_prefixes='psql';
SELECT format('SELECT %L AS fragmento, matricula, nome, email, curso FROM %I.%I ORDER BY matricula;', schemaname||'.'||tablename, schemaname, tablename)
FROM pg_tables WHERE schemaname='public' AND tablename ~ '^alunos_[0-9]+$' ORDER BY tablename
\gexec
SQL
    ;;
  inspecionar-mongo)
    mongo lab-mongo-router 27017 --eval "printjson(db.hello()); printjson(db.getSiblingDB('labdb').alunos.find().sort({matricula:1}).toArray()); sh.status(); printjson(db.getSiblingDB('labdb').alunos.find({matricula:Long('100001')}).explain('executionStats'));" ;;
  inspecionar-shard-a|inspecionar-shard-b)
    if [[ $1 == *-a ]]; then name=lab-mongo-sa; port=27018; else name=lab-mongo-sb; port=27020; fi
    mongo "$name" "$port" --eval "printjson(db.hello()); printjson(db.getSiblingDB('labdb').alunos.find().sort({matricula:1}).toArray());" ;;
  status) run ps -a --filter 'name=lab-' --format 'table {{.Names}}\t{{.Status}}\t{{.Image}}' ;;
  parar)
    case "${2:-}" in
      pg) names=(lab-pg-a lab-pg-b);;
      citus) names=(lab-citus-coord lab-citus-wa lab-citus-wb);;
      mongo) names=(lab-mongo-router lab-mongo-config lab-mongo-sa lab-mongo-sb);;
      *) echo 'Use: lab.sh parar pg|citus|mongo'; exit 1;;
    esac
    for name in "${names[@]}"; do if run container inspect "$name" >/dev/null 2>&1; then run rm -f "$name"; fi; done ;;
  *) echo 'Comandos: pg-a pg-b citus-a citus-b citus-init mongo-a mongo-b mongo-init-a mongo-init-b mongo-router mongo-init inspecionar-pg-a inspecionar-pg-b inspecionar-citus inspecionar-worker-a inspecionar-worker-b inspecionar-mongo inspecionar-shard-a inspecionar-shard-b status parar'; exit 1;;
esac
