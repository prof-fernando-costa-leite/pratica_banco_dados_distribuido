#!/usr/bin/env bash
set -euo pipefail
psql -v ON_ERROR_STOP=1 --username postgres --dbname labdb --set=pass="$LAB_PASSWORD" <<'SQL'
CREATE ROLE lab LOGIN PASSWORD :'pass';
CREATE ROLE replicador REPLICATION LOGIN PASSWORD :'pass';
GRANT CONNECT ON DATABASE labdb TO lab;
GRANT USAGE, CREATE ON SCHEMA public TO lab;
SQL
if [[ ${LAB_CREATE_TABLE:-1} == 1 ]]; then
psql -v ON_ERROR_STOP=1 --username postgres --dbname labdb <<'SQL'
CREATE TABLE IF NOT EXISTS alunos (
  matricula BIGINT PRIMARY KEY CHECK (matricula > 0),
  nome TEXT NOT NULL, email TEXT NOT NULL, curso TEXT NOT NULL
);
ALTER TABLE alunos OWNER TO lab;
SQL
fi
printf '*:*:*:*:%s\n' "$LAB_PASSWORD" > "$PGDATA/lab.pgpass"
chmod 600 "$PGDATA/lab.pgpass"
# Basebackup autentica pelo papel replicador, restrito aos hosts do laboratório.
printf '\nhost replication replicador %s/32 scram-sha-256\nhost replication replicador %s/32 scram-sha-256\n' "$NODE_A" "$NODE_B" >> "$PGDATA/pg_hba.conf"
