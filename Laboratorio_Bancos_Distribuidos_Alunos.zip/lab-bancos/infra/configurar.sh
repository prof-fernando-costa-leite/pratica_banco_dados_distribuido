#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ -e .env || -e secrets/mongo-key ]]; then echo 'Configuração já existe; não sobrescrevi segredos.'; exit 1; fi
read -rp 'IPv4 PRIVADO da EC2 A: ' NODE_A
read -rp 'IPv4 PRIVADO da EC2 B: ' NODE_B
for ip in "$NODE_A" "$NODE_B"; do
  [[ $ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo 'Informe um IPv4.'; exit 1; }
done
umask 077
mkdir -p secrets
openssl rand -base64 512 > secrets/mongo-key
SECRET=$(openssl rand -hex 20)
cat > .env <<ENV
NODE_A=$NODE_A
NODE_B=$NODE_B
LAB_PASSWORD=$SECRET
POSTGRES_PASSWORD=$SECRET
POSTGRES_DB=labdb
MONGO_USER=labadmin
MONGO_PASSWORD=$SECRET
PG_IMAGE=postgres:17.6@sha256:00bc86618629af00d2937fdc5a5d63db3ff8450acf52f0636ec813c7f4902929
CITUS_IMAGE=citusdata/citus:13.0.1@sha256:d2474464858e7b9120b906f5e4e8901a6fc1392cab0f79ae87bdfc0424fa49bb
MONGO_IMAGE=mongo:8.0.13@sha256:cf340b1e5283843c63eb12999922f20c463ae31285f746d30f05dcc21cd1d47c
ENV
printf 'Configuração criada em infra/.env. Copie a mesma pasta infra para B, incluindo .env e secrets.\n'
