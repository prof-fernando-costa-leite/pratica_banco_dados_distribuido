# Laboratório de bancos de dados distribuídos

Material para três etapas práticas com duas EC2 de 4 GiB, uma etapa ativa por vez:

1. PostgreSQL: primário e réplica de leitura, com atraso de 15 segundos.
2. PostgreSQL + Citus: coordenador e dois workers, com fragmentação por hash.
3. MongoDB: mongos, config server e dois shards, com fragmentação por faixas.

Abra `INICIO.html` no navegador para ler os roteiros offline e imprimir/salvar em PDF.

## Comece aqui

Professor: leia [roteiro de ensaio e condução](docs/04-ROTEIRO-PROFESSOR.md) e [registro de validação](docs/VALIDACAO.md).

Alunos:

- [Preparação das duas EC2 e do cliente local](docs/00-PREPARACAO.md).
- [Etapa 1 — PostgreSQL replicado](docs/01-POSTGRES-REPLICADO.md).
- [Etapa 2 — PostgreSQL + Citus](docs/02-POSTGRES-CITUS.md).
- [Etapa 3 — MongoDB com sharding](docs/03-MONGODB-SHARDING.md).

## Aplicativo

Os executáveis ficam em `dist/`. Execute o correspondente à sua arquitetura x86_64. Não há instalação local de Rust, Python, drivers ou cliente SSH. A aplicação se conecta aos bancos por túneis SSH incorporados, validando a impressão digital do servidor. As senhas são digitadas sem eco e não são salvas.

Windows: `dist/lab-bancos-windows-x86_64.exe`.

Linux: dê permissão com `chmod +x dist/lab-bancos-linux-x86_64` e execute `./dist/lab-bancos-linux-x86_64`.

A aplicação implementa cadastrar, buscar, listar, atualizar, excluir, gerar 20 exemplos e identificar conexões/fragmentos. A matrícula é inteira positiva e imutável. Não há API HTTP ou Nginx.

## Infraestrutura

A pasta `infra/` deve ir para as EC2. Docker é instalado somente nos servidores. As duas EC2 precisam receber o mesmo `.env` e a mesma chave interna MongoDB, gerados durante a preparação. Nenhum segredo real é incluído no pacote.

Use as consultas de inspeção em cada roteiro para comprovar a localização física dos dados. O coordenador Citus e o mongos não devem ser confundidos com o nó que guarda o registro.

O laboratório demonstra mecanismos com topologia mínima; não oferece failover automático nem redundância dos shards. Dados são fictícios. Antes da distribuição à turma, execute o ensaio AWS e o teste dos binários nas máquinas institucionais.

## Fonte e reconstrução

Código Rust em `app/src/`; versões resolvidas em `app/Cargo.lock`; [instruções de compilação](docs/05-COMPILACAO.md); [fontes técnicas](docs/FONTES.md).
