#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
ROOT=$PWD
docker build -t lab-bancos-builder -f app/Dockerfile.build app
docker run --rm -e CARGO_TARGET_X86_64_UNKNOWN_LINUX_MUSL_LINKER=rust-lld -v "$ROOT/app:/work" -v lab-bancos-cargo:/usr/local/cargo/registry lab-bancos-builder bash -c '
  cargo test --locked
  cargo build --locked --release --target x86_64-unknown-linux-musl
  cargo build --locked --release --target x86_64-pc-windows-gnu
'
mkdir -p dist
cp app/target/x86_64-unknown-linux-musl/release/lab-bancos dist/lab-bancos-linux-x86_64
cp app/target/x86_64-pc-windows-gnu/release/lab-bancos.exe dist/lab-bancos-windows-x86_64.exe
(cd dist && sha256sum lab-bancos-linux-x86_64 lab-bancos-windows-x86_64.exe > SHA256SUMS.txt)
echo 'Binários disponíveis em dist/.'
