mod tunnel;
use anyhow::{bail, Context, Result};
use futures_util::TryStreamExt;
use mongodb::{
    bson::{doc, Document},
    options::{ClientOptions, Credential, ServerAddress},
    Client as Mongo,
};
use std::{
    io::{self, Write},
    time::Duration,
};
use tokio_postgres::{Client as Pg, NoTls};
use tunnel::Tunnel;

#[derive(Debug, Clone, PartialEq)]
struct Aluno {
    matricula: i64,
    nome: String,
    email: String,
    curso: String,
}
impl Aluno {
    fn document(&self) -> Document {
        doc! {"matricula":self.matricula,"nome":&self.nome,"email":&self.email,"curso":&self.curso}
    }
    fn from_doc(d: Document) -> Result<Self> {
        Ok(Self {
            matricula: d.get_i64("matricula")?,
            nome: d.get_str("nome")?.into(),
            email: d.get_str("email")?.into(),
            curso: d.get_str("curso")?.into(),
        })
    }
    fn row(r: tokio_postgres::Row) -> Self {
        Self {
            matricula: r.get(0),
            nome: r.get(1),
            email: r.get(2),
            curso: r.get(3),
        }
    }
}

enum Backend {
    Postgres {
        write: Pg,
        read: Pg,
        distributed: bool,
    },
    Mongo {
        client: Mongo,
        db: String,
    },
}
impl Backend {
    async fn pg(
        w: u16,
        r: u16,
        user: &str,
        pass: &str,
        db: &str,
        distributed: bool,
    ) -> Result<Self> {
        async fn connect(port: u16, user: &str, pass: &str, db: &str) -> Result<Pg> {
            let mut cfg = tokio_postgres::Config::new();
            cfg.host("127.0.0.1")
                .port(port)
                .user(user)
                .password(pass)
                .dbname(db)
                .connect_timeout(Duration::from_secs(10))
                .options("-c statement_timeout=15000");
            let (client, connection) = cfg.connect(NoTls).await?;
            tokio::spawn(async move {
                if let Err(e) = connection.await {
                    eprintln!("Conexão PostgreSQL encerrada: {e}");
                }
            });
            Ok(client)
        }
        let write = connect(w, user, pass, db).await?;
        let read = connect(r, user, pass, db).await?;
        let wr: bool = write
            .query_one("SELECT pg_is_in_recovery()", &[])
            .await?
            .get(0);
        let rr: bool = read
            .query_one("SELECT pg_is_in_recovery()", &[])
            .await?
            .get(0);
        if wr || (!distributed && !rr) {
            bail!("Papéis incorretos: escrita deve ser primário e leitura deve ser réplica no cenário 1.");
        }
        if distributed {
            write
                .query_one(
                    "SELECT extversion FROM pg_extension WHERE extname='citus'",
                    &[],
                )
                .await
                .context("A conexão não é um coordenador Citus")?;
        }
        Ok(Self::Postgres {
            write,
            read,
            distributed,
        })
    }
    async fn mongo(port: u16, user: &str, pass: &str, db: &str) -> Result<Self> {
        let mut opts = ClientOptions::default();
        opts.hosts = vec![ServerAddress::Tcp {
            host: "127.0.0.1".into(),
            port: Some(port),
        }];
        opts.credential = Some(
            Credential::builder()
                .username(user.to_owned())
                .password(pass.to_owned())
                .source(db.to_owned())
                .build(),
        );
        opts.server_selection_timeout = Some(Duration::from_secs(10));
        opts.connect_timeout = Some(Duration::from_secs(10));
        opts.max_pool_size = Some(4);
        let client = Mongo::with_options(opts)?;
        let h = client
            .database("admin")
            .run_command(doc! {"hello":1})
            .await?;
        if h.get_str("msg").unwrap_or("") != "isdbgrid" {
            bail!("Conecte ao mongos, não diretamente a um shard.");
        }
        client.database(db).run_command(doc! {"ping":1}).await?;
        Ok(Self::Mongo {
            client,
            db: db.into(),
        })
    }
    async fn origin(&self, reading: bool) -> Result<()> {
        match self {
            Self::Postgres {
                read,
                write,
                distributed,
            } => {
                let c = if reading { read } else { write };
                let r=c.query_one("SELECT current_setting('cluster_name'),pg_is_in_recovery(),host(inet_server_addr()),inet_server_port()",&[]).await?;
                println!(
                    "Servidor respondeu: {} | {}:{} | réplica={}",
                    r.get::<_, String>(0),
                    r.get::<_, String>(2),
                    r.get::<_, i32>(3),
                    r.get::<_, bool>(1)
                );
                if *distributed {
                    println!("Este é o coordenador. Os registros físicos estão nos workers; confira por SSH.");
                }
            }
            Self::Mongo { client, .. } => {
                let h = client
                    .database("admin")
                    .run_command(doc! {"hello":1})
                    .await?;
                println!("Servidor respondeu: {} (roteador). Consulte explain e os shards para a localização física.",h.get_str("msg").unwrap_or("desconhecido"));
            }
        }
        Ok(())
    }
    async fn insert(&self, a: &Aluno) -> Result<u64> {
        match self {
            Self::Postgres { write, .. } => Ok(write
                .execute(
                    "INSERT INTO alunos(matricula,nome,email,curso) VALUES($1,$2,$3,$4)",
                    &[&a.matricula, &a.nome, &a.email, &a.curso],
                )
                .await?),
            Self::Mongo { client, db } => {
                client
                    .database(db)
                    .collection::<Document>("alunos")
                    .insert_one(a.document())
                    .await?;
                Ok(1)
            }
        }
    }
    async fn list(&self, id: Option<i64>) -> Result<Vec<Aluno>> {
        match self {
            Self::Postgres { read, .. } => {
                let rows = if let Some(id) = id {
                    read.query(
                        "SELECT matricula,nome,email,curso FROM alunos WHERE matricula=$1",
                        &[&id],
                    )
                    .await?
                } else {
                    read.query("SELECT matricula,nome,email,curso FROM alunos ORDER BY matricula LIMIT 100",&[]).await?
                };
                Ok(rows.into_iter().map(Aluno::row).collect())
            }
            Self::Mongo { client, db } => {
                let filter = id.map(|n| doc! {"matricula":n}).unwrap_or_default();
                let ds: Vec<Document> = client
                    .database(db)
                    .collection("alunos")
                    .find(filter)
                    .sort(doc! {"matricula":1})
                    .limit(100)
                    .await?
                    .try_collect()
                    .await?;
                ds.into_iter().map(Aluno::from_doc).collect()
            }
        }
    }
    async fn update(&self, a: &Aluno) -> Result<u64> {
        match self {
            Self::Postgres { write, .. } => Ok(write
                .execute(
                    "UPDATE alunos SET nome=$2,email=$3,curso=$4 WHERE matricula=$1",
                    &[&a.matricula, &a.nome, &a.email, &a.curso],
                )
                .await?),
            Self::Mongo { client, db } => Ok(client
                .database(db)
                .collection::<Document>("alunos")
                .update_one(
                    doc! {"matricula":a.matricula},
                    doc! {"$set":{"nome":&a.nome,"email":&a.email,"curso":&a.curso}},
                )
                .await?
                .matched_count),
        }
    }
    async fn delete(&self, id: i64) -> Result<u64> {
        match self {
            Self::Postgres { write, .. } => Ok(write
                .execute("DELETE FROM alunos WHERE matricula=$1", &[&id])
                .await?),
            Self::Mongo { client, db } => Ok(client
                .database(db)
                .collection::<Document>("alunos")
                .delete_one(doc! {"matricula":id})
                .await?
                .deleted_count),
        }
    }
    async fn locate(&self, id: i64) -> Result<()> {
        match self {
        Self::Postgres{write,distributed:true,..}=>{
            for r in write.query("SELECT shardid,nodename,nodeport FROM citus_shards WHERE table_name='alunos'::regclass AND shardid=get_shard_id_for_distribution_column('alunos',$1::bigint)",&[&id]).await?{
                println!("matrícula {id} -> shard {} -> {}:{}",r.get::<_,i64>(0),r.get::<_,String>(1),r.get::<_,i32>(2));
            }
        },
        Self::Postgres{..}=>println!("Replicação: o registro deve existir no primário e, após o atraso, na réplica. Verifique os dois por SSH."),
        Self::Mongo{client,db}=>{let d=client.database(db).run_command(doc!{"explain":{"find":"alunos","filter":{"matricula":id}},"verbosity":"executionStats"}).await?;let plan=d.get_document("queryPlanner")?.get_document("winningPlan")?;
            println!("Plano: {}",plan.get_str("stage").unwrap_or("ver explain no mongosh"));
            if let Ok(shards)=plan.get_array("shards") {
                for shard in shards { if let Some(s)=shard.as_document() {
                    println!("matrícula {id} -> shard {} -> {}",s.get_str("shardName").unwrap_or("?"),s.get_str("connectionString").unwrap_or("?"));
                }}
            }
            println!("Origem obtida pelo explain do mongos. Confira os documentos no shard por SSH.");}
    }
        Ok(())
    }
}
fn ask(label: &str, default: &str) -> Result<String> {
    if default.is_empty() {
        print!("{label}: ");
    } else {
        print!("{label} [{default}]: ");
    }
    io::stdout().flush()?;
    let mut s = String::new();
    if io::stdin().read_line(&mut s)? == 0 {
        bail!("Entrada encerrada");
    }
    let s = s.trim();
    Ok(if s.is_empty() {
        default.into()
    } else {
        s.into()
    })
}
fn matricula(s: &str) -> Result<i64> {
    let n: i64 = s.parse().context("Matrícula deve ser um número inteiro")?;
    if n <= 0 {
        bail!("Matrícula deve ser positiva");
    }
    Ok(n)
}
fn fields(id: i64) -> Result<Aluno> {
    let nome = ask("Nome", "")?;
    let email = ask("E-mail", "")?;
    let curso = ask("Curso", "")?;
    if nome.is_empty() || email.is_empty() || curso.is_empty() {
        bail!("Preencha os três campos");
    }
    Ok(Aluno {
        matricula: id,
        nome,
        email,
        curso,
    })
}
async fn endpoint(label: &str, port: u16, key: &str, phrase: &str) -> Result<Tunnel> {
    println!("\n{label}");
    let host = ask("Endereço PÚBLICO da EC2", "")?;
    let user = ask("Usuário SSH", "ubuntu")?;
    let fp = ask(
        "Fingerprint SHA256 da chave ED25519 do SERVIDOR (console AWS)",
        "",
    )?;
    let port: u16 = ask("Porta do banco NA EC2", &port.to_string())?.parse()?;
    Tunnel::open(&host, 22, &user, key, phrase, &fp, port).await
}
async fn configure(stage: &str) -> Result<(Backend, Vec<Tunnel>)> {
    println!("Túnel SSH incorporado; nenhuma senha ou chave será salva.");
    let key = ask("Caminho do arquivo de chave privada (.pem)", "")?;
    let phrase = rpassword::prompt_password("Frase secreta da chave (Enter se não houver): ")?;
    let a = endpoint(
        "EC2 A",
        match stage {
            "1" => 5432,
            "2" => 5540,
            _ => 27017,
        },
        &key,
        &phrase,
    )
    .await?;
    let mut tunnels = vec![a];
    if stage == "1" {
        tunnels.push(endpoint("EC2 B — réplica", 5433, &key, &phrase).await?);
    }
    let db = ask("Banco de dados", "labdb")?;
    let user = ask("Usuário do banco", "lab")?;
    let pass = rpassword::prompt_password("Senha do banco: ")?;
    let backend = match stage {
        "1" => Backend::pg(tunnels[0].port, tunnels[1].port, &user, &pass, &db, false).await?,
        "2" => Backend::pg(tunnels[0].port, tunnels[0].port, &user, &pass, &db, true).await?,
        _ => Backend::mongo(tunnels[0].port, &user, &pass, &db).await?,
    };
    backend.origin(true).await?;
    Ok((backend, tunnels))
}
async fn operation(b: &Backend, op: &str) -> Result<()> {
    let reading = matches!(op, "2" | "3");
    if op != "7" {
        b.origin(reading).await?;
    }
    match op {
        "1" => {
            let id = matricula(&ask("Matrícula", "")?)?;
            let a = fields(id)?;
            println!("{} registro inserido.", b.insert(&a).await?);
        }
        "2" | "3" => {
            let id = if op == "2" {
                Some(matricula(&ask("Matrícula", "")?)?)
            } else {
                None
            };
            let rows = b.list(id).await?;
            if rows.is_empty() {
                println!("Nenhum registro encontrado nesta leitura.");
            }
            for a in &rows {
                println!("{} | {} | {} | {}", a.matricula, a.nome, a.email, a.curso);
            }
            println!("{} registro(s). Listagem limitada a 100.", rows.len());
        }
        "4" => {
            let id = matricula(&ask("Matrícula (imutável)", "")?)?;
            let a = fields(id)?;
            println!(
                "{} registro(s) encontrado(s) para atualizar.",
                b.update(&a).await?
            );
        }
        "5" => {
            let id = matricula(&ask("Matrícula", "")?)?;
            if ask("Digite EXCLUIR para confirmar", "")? == "EXCLUIR" {
                println!("{} registro(s) excluído(s).", b.delete(id).await?);
            }
        }
        "6" => {
            println!("Serão inseridos 100001..100010 e 700001..700010. IDs existentes não serão sobrescritos.");
            if ask("Continuar? s/n", "n")? == "s" {
                let mut count = 0;
                for base in [100000, 700000] {
                    for i in 1..=10 {
                        let id = base + i;
                        let a = Aluno {
                            matricula: id,
                            nome: format!("Aluno {id}"),
                            email: format!("aluno{id}@example.test"),
                            curso: "Sistemas Distribuídos".into(),
                        };
                        match b.insert(&a).await {
                            Ok(_) => count += 1,
                            Err(e) => println!("{id}: {e}"),
                        }
                    }
                }
                println!("{count} registros inseridos.");
            }
        }
        "7" => {
            b.origin(true).await?;
            b.origin(false).await?;
        }
        "8" => {
            let id = matricula(&ask("Matrícula para localizar", "")?)?;
            b.locate(id).await?;
        }
        _ => println!("Opção inválida."),
    }
    Ok(())
}
async fn smoke(stage: &str) -> Result<()> {
    let p = std::env::var("LAB_PASSWORD")?;
    let mut tunnels = Vec::new();
    let mut ports = [5432, 5433, 5540, 27017];
    if let Ok(host) = std::env::var("LAB_SSH_HOST") {
        let key = std::env::var("LAB_SSH_KEY")?;
        let fp = std::env::var("LAB_SSH_FP")?;
        let user = std::env::var("LAB_SSH_USER").unwrap_or("ubuntu".into());
        let ssh_port = std::env::var("LAB_SSH_PORT")
            .unwrap_or("22".into())
            .parse()?;
        for port in &mut ports {
            let t = Tunnel::open(&host, ssh_port, &user, &key, "", &fp, *port).await?;
            *port = t.port;
            tunnels.push(t);
        }
    }
    let b = match stage {
        "1" => Backend::pg(ports[0], ports[1], "lab", &p, "labdb", false).await?,
        "2" => Backend::pg(ports[2], ports[2], "lab", &p, "labdb", true).await?,
        "3" => Backend::mongo(ports[3], "lab", &p, "labdb").await?,
        _ => bail!("Etapa inválida"),
    };
    b.origin(true).await?;
    let mut a = Aluno {
        matricula: 900000001,
        nome: "Teste de integração".into(),
        email: "teste@example.test".into(),
        curso: "SD".into(),
    };
    if !b.list(Some(a.matricula)).await?.is_empty() {
        bail!("Matrícula de teste já existe; não será removida automaticamente");
    }
    assert_eq!(b.insert(&a).await?, 1);
    assert!(b.insert(&a).await.is_err(), "Duplicata deve falhar");
    if stage == "1" {
        assert!(b.list(Some(a.matricula)).await?.is_empty());
        tokio::time::sleep(Duration::from_secs(17)).await;
    }
    assert_eq!(b.list(Some(a.matricula)).await?, vec![a.clone()]);
    b.locate(a.matricula).await?;
    a.nome = "Atualizado".into();
    assert_eq!(b.update(&a).await?, 1);
    if stage == "1" {
        tokio::time::sleep(Duration::from_secs(17)).await;
    }
    assert_eq!(b.list(Some(a.matricula)).await?, vec![a.clone()]);
    assert_eq!(b.delete(a.matricula).await?, 1);
    if stage == "1" {
        assert_eq!(b.list(Some(a.matricula)).await?.len(), 1);
        tokio::time::sleep(Duration::from_secs(17)).await;
    }
    assert!(b.list(Some(a.matricula)).await?.is_empty());
    assert_eq!(b.delete(a.matricula).await?, 0);
    println!("SMOKE ETAPA {stage}: OK");
    Ok(())
}
#[tokio::main]
async fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    if args.get(1).map(String::as_str) == Some("--smoke") {
        return smoke(args.get(2).context("Informe etapa")?).await;
    }
    if args.get(1).map(String::as_str) == Some("--version") {
        println!("lab-bancos 1.0.0");
        return Ok(());
    }
    loop {
        println!("\nLABORATÓRIO DE BANCOS DISTRIBUÍDOS\n1. PostgreSQL replicado\n2. PostgreSQL + Citus\n3. MongoDB com sharding\n0. Sair");
        let stage = ask("Cenário", "")?;
        if stage == "0" {
            return Ok(());
        }
        if !matches!(stage.as_str(), "1" | "2" | "3") {
            continue;
        }
        let (b, _tunnels) = match configure(&stage).await {
            Ok(v) => v,
            Err(e) => {
                eprintln!("Conexão falhou: {e:#}");
                continue;
            }
        };
        loop {
            println!("\n1. Cadastrar\n2. Buscar por matrícula\n3. Listar\n4. Atualizar\n5. Excluir\n6. Inserir 20 exemplos\n7. Identificar conexões\n8. Localizar fragmento / explicar consulta\n9. Trocar cenário\n0. Sair");
            let op = ask("Opção", "")?;
            if op == "0" {
                return Ok(());
            }
            if op == "9" {
                break;
            }
            if let Err(e) = operation(&b, &op).await {
                eprintln!("Operação falhou: {e:#}\nSe houve perda de conexão durante escrita, o resultado pode ser incerto. Confira os dados antes de repetir.");
            }
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn matriculas_invalidas() {
        for s in ["0", "-1", "abc", "9223372036854775808"] {
            assert!(matricula(s).is_err());
        }
        assert_eq!(matricula("700001").unwrap(), 700001);
    }
    #[test]
    fn bson_preserva_inteiro_longo_e_unicode() {
        let a = Aluno {
            matricula: 700001,
            nome: "João D'Ávila".into(),
            email: "j@example.test".into(),
            curso: "Computação".into(),
        };
        assert_eq!(Aluno::from_doc(a.document()).unwrap(), a);
    }
}
