use anyhow::{bail, Context, Result};
use russh::{
    client,
    keys::{self, HashAlg, PrivateKeyWithHashAlg, PublicKeyOrCertificate},
};
use std::{sync::Arc, time::Duration};
use tokio::{
    net::TcpListener,
    task::{JoinHandle, JoinSet},
};

struct VerifyHost {
    fingerprint: String,
}
impl client::Handler for VerifyHost {
    type Error = anyhow::Error;
    async fn check_server_key(&mut self, key: &PublicKeyOrCertificate) -> Result<bool> {
        let received = key.public_key().fingerprint(HashAlg::Sha256).to_string();
        if received != self.fingerprint {
            bail!(
                "Fingerprint SSH diferente. Esperado: {}; recebido: {}. Confira pelo console AWS.",
                self.fingerprint,
                received
            );
        }
        Ok(true)
    }
}

pub struct Tunnel {
    pub port: u16,
    task: JoinHandle<()>,
}
impl Drop for Tunnel {
    fn drop(&mut self) {
        self.task.abort();
    }
}

impl Tunnel {
    pub async fn open(
        host: &str,
        ssh_port: u16,
        user: &str,
        key_path: &str,
        passphrase: &str,
        fingerprint: &str,
        remote_port: u16,
    ) -> Result<Self> {
        let key = keys::load_secret_key(
            key_path,
            if passphrase.is_empty() {
                None
            } else {
                Some(passphrase)
            },
        )
        .context("Não foi possível ler a chave privada SSH")?;
        let mut config = client::Config {
            keepalive_interval: Some(Duration::from_secs(15)),
            ..Default::default()
        };
        config.preferred.key = vec![keys::Algorithm::Ed25519].into();
        let mut session = tokio::time::timeout(
            Duration::from_secs(15),
            client::connect(
                Arc::new(config),
                (host, ssh_port),
                VerifyHost {
                    fingerprint: fingerprint.trim().to_owned(),
                },
            ),
        )
        .await
        .context("Timeout SSH: confira IP público e Security Group")??;
        let hash = session.best_supported_rsa_hash().await?.flatten();
        let auth = session
            .authenticate_publickey(user, PrivateKeyWithHashAlg::new(Arc::new(key), hash))
            .await?;
        if !auth.success() {
            bail!("Autenticação SSH recusada. Confira usuário e chave.");
        }
        let session = Arc::new(session);
        let listener = TcpListener::bind(("127.0.0.1", 0)).await?;
        let port = listener.local_addr()?.port();
        let task = tokio::spawn(async move {
            let mut connections = JoinSet::new();
            loop {
                tokio::select! {
                    accepted = listener.accept() => {
                        let Ok((mut socket, peer)) = accepted else { break };
                        let ssh = session.clone();
                        connections.spawn(async move {
                            match ssh.channel_open_direct_tcpip("127.0.0.1", remote_port.into(), "127.0.0.1", peer.port().into()).await {
                                Ok(channel) => { let mut stream=channel.into_stream(); let _=tokio::io::copy_bidirectional(&mut socket,&mut stream).await; }
                                Err(e) => eprintln!("Falha no túnel da porta {}: {}", remote_port, e),
                            }
                        });
                    }
                    Some(_) = connections.join_next(), if !connections.is_empty() => {}
                }
            }
        });
        Ok(Self { port, task })
    }
}
