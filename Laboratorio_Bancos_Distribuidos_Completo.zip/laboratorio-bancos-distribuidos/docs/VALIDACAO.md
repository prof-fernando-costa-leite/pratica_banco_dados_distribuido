# Registro de validação — 22/09/2026

## Ambiente utilizado

Host Linux x86_64 com Docker 29.8.0. Os processos que representam A e B foram executados no mesmo host, usando portas distintas e 127.0.0.1. A validação comprova os comandos e protocolos nas versões abaixo, mas não reproduz dois domínios de falha ou a rede AWS.

Compilador: Rust 1.98.1. Dependências resolvidas em `app/Cargo.lock`.

Imagens verificadas e fixadas por digest em `infra/configurar.sh`:

- PostgreSQL 17.6.
- Citus 13.0.1.
- MongoDB 8.0.13.

## Verificações concluídas

- Sintaxe dos scripts Bash.
- Inicialização do primário PostgreSQL e basebackup da réplica.
- Identificação do primário e da réplica pelo próprio PostgreSQL.
- Streaming assíncrono com `recovery_min_apply_delay=15s`.
- CRUD real pelo cliente Rust: inserir, rejeitar duplicata, ler, atualizar, excluir e identificar exclusão de registro inexistente.
- Etapa 1 executada pelo túnel SSH incorporado: registro ausente imediatamente após insert e presente após a espera; estado atualizado e exclusão propagados.
- Recusa de INSERT direto na réplica de leitura.
- Coordenador Citus com dois workers e quatro fragmentos.
- Carga de 20 registros no Citus: 12 no worker A e 8 no B; soma física igual à visão lógica.
- Localização de matrícula pelo catálogo Citus e pelo identificador calculado do fragmento.
- MongoDB com config server, mongos e dois shards, cada replica set com um membro.
- Faixas MongoDB com corte em 500000, configuradas antes da inserção.
- Carga de 20 registros MongoDB: dez no shard A e dez no B; visão lógica com vinte.
- Explain MongoDB de busca por matrícula identificando `SINGLE_SHARD` e o shard responsável.
- Falha parcial Citus: busca em A funciona com B parado; busca em B e consulta global falham.
- Falha parcial MongoDB: busca em A funciona com B parado; busca em B e consulta global falham.
- Recuperação dos processos de B após os testes de falha.
- Recriação dos contêineres Citus e MongoDB, preservando volumes: CRUD por SSH e localização continuaram funcionando sem repetir inicialização.
- Autenticação SSH por chave RSA PEM e recusa de fingerprint de servidor incorreto.
- Dois testes unitários: validação de matrícula e preservação de inteiro BSON/Unicode.
- Binário Linux verificado como ELF x86_64 static PIE e executado sem instalação de runtime.
- Binário Windows compilado como PE32+ console x86_64. Importações verificadas: DLLs do sistema Windows, sem DLL adicional do compilador/driver para distribuir.

Os testes de distribuição e falha parcial estão em `tests/`. O modo `--smoke` está descrito nas instruções de compilação. As matrículas usadas são fictícias e não correspondem a dados reais de alunos.

## Consumo observado

Em uma amostra ociosa, os três processos MongoDB de armazenamento consumiram aproximadamente 121–130 MiB cada, e o mongos cerca de 24 MiB. Os processos Citus ficaram em aproximadamente 41–44 MiB cada. Esses números são observações do fixture local, não dimensionamento garantido de produção nem resultado de carga concorrente.

As EC2 propostas têm 4 GiB, mas os testes locais não impuseram um limite total de 4 GiB por grupo de processos. Execute uma etapa por vez e confirme consumo durante o ensaio AWS.

## Ainda exige homologação do professor

- Provisionamento real de duas EC2, instalação do Docker em Ubuntu 24.04 e comportamento do Security Group/VPC.
- Comunicação entre IPs privados distintos e acesso por dois endereços públicos.
- Túnel SSH pela rede da universidade, incluindo eventual bloqueio de saída TCP 22.
- Execução do binário Windows em Windows 10/11 x86_64 real. O pacote foi compilado e inspecionado, mas não executado em um Windows real nesta sessão.
- Permissões e políticas dos computadores institucionais, tanto Windows quanto Linux.
- Teste de acesso ao terminal AWS no navegador pela modalidade escolhida.
- Comportamento sob a quantidade real de alunos simultâneos e confirmação dos custos AWS.

A ausência de provisionamento AWS nesta sessão é intencional: este pacote prepara o ensaio do professor e não cria recursos cobrados automaticamente.
