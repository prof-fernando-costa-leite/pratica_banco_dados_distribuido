# Compilação — somente professor/desenvolvedor

Os alunos usam os executáveis em `dist` e não precisam desta etapa.

## Ambiente reproduzível em Docker Linux

A imagem de compilação usa Rust 1.98.1, fixado pelo digest da imagem no Dockerfile. O `Cargo.lock` fixa as dependências. A biblioteca SSH é Russh; os drivers são tokio-postgres e o driver oficial MongoDB Rust. As credenciais de banco são passadas por campos dos drivers, sem interpolar senhas em URLs.

Na raiz do pacote, em um computador Linux com Docker:

```bash
bash compilar.sh
```

O script prepara ferramentas em contêiner, roda testes unitários e produz:

- Linux x86_64, target `x86_64-unknown-linux-musl`, vinculação estática explícita.
- Windows x86_64, target `x86_64-pc-windows-gnu`, vinculação estática do runtime de compilação.

O build Windows é cruzado. A execução em um Windows real continua sendo uma etapa obrigatória de homologação; compilação e inspeção de DLLs não comprovam a política de execução da universidade.

## Compilação nativa alternativa

Com Rust instalado apenas no computador de desenvolvimento:

```bash
cd app
cargo test --locked
cargo build --release --locked
```

Nesse caso o binário usa o target nativo e suas dependências de sistema. Não substitua automaticamente o Linux estático por um binário GNU compilado em uma distribuição mais nova que a dos alunos.

## Configuração do cliente

`src/main.rs`: menu, validação de matrícula, drivers, CRUD e diagnóstico.

`src/tunnel.rs`: validação da identidade SSH, autenticação por chave e encaminhamento TCP. O servidor deve apresentar chave ED25519. A chave de autenticação do aluno pode ser RSA PEM ou ED25519/OpenSSH.

O cliente não executa shell remoto, não envia chave privada ao servidor e não usa um programa `ssh` externo. Um listener temporário em `127.0.0.1` encaminha as conexões do driver pelo SSH e é encerrado ao trocar de cenário/sair.

Os bancos não usam TLS dentro do túnel neste laboratório; o transporte entre computador local e EC2 é cifrado pelo SSH. A comunicação interna entre nós usa a VPC e autenticação dos bancos, sem configuração adicional de TLS entre os nós.

## Teste de integração opcional

O binário contém `--smoke 1`, `--smoke 2` e `--smoke 3` para validar o CRUD em um ambiente de teste. Ele lê `LAB_PASSWORD` e usa as portas locais dos roteiros. O teste usa a matrícula reservada `900000001`, recusa sobrescrever um registro existente e remove os dados de teste ao terminar com sucesso.

Na etapa 1 há esperas de 17 segundos entre verificações, para testar o atraso configurado em 15 s. Não execute com outro atraso sem ajustar o teste.

Para exercitar o túnel, também defina `LAB_SSH_HOST`, `LAB_SSH_PORT` (padrão 22), `LAB_SSH_USER`, `LAB_SSH_KEY` e `LAB_SSH_FP`. Esse modo de teste usa o mesmo host SSH para alcançar as quatro portas no fixture local; não é um substituto do ensaio com A e B reais.

O código de teste e `tests/Dockerfile.ssh` existem para desenvolvimento em ambiente descartável. Não use a imagem SSH de fixture em uma EC2 de aula.
