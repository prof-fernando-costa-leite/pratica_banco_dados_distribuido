# Roteiro do professor — ensaio, condução e diagnóstico

## O que este pacote entrega

Três roteiros progressivos, scripts de infraestrutura auditáveis e um cliente de terminal Rust para Windows/Linux x86_64, com drivers e túnel SSH incorporados. O modelo é uma tabela/coleção de alunos: matrícula inteira imutável, nome, e-mail e curso.

A escolha de Rust atende à restrição de não instalar runtimes nos computadores locais. Python também poderia ser empacotado, mas exigiria um empacotador e não reduziria as validações por sistema operacional. C++ acrescentaria trabalho com drivers e dependências. Os alunos recebem o executável; o professor recebe também fonte, lockfile e instruções de compilação.

**Competência final:** o aluno deve relacionar uma operação lógica de CRUD com a origem efetiva da leitura, a propagação de uma escrita ou a localização do fragmento, incluindo comportamento sob falha parcial.

## 1. Antes de distribuir aos alunos

Use [VALIDACAO.md](VALIDACAO.md) para distinguir testes já executados de testes pendentes. A execução em contêineres locais não comprova regras da VPC, conectividade SSH da universidade ou liberação do executável no Windows institucional.

Faça um ensaio completo com duas EC2 e com pelo menos um computador de cada sistema operacional. Não há recursos AWS provisionados automaticamente pelo pacote.

Checklist de preparação:

- [ ] Confirmar Windows x86_64 e Linux x86_64; verificar permissão para executar binários na pasta do aluno.
- [ ] Confirmar saída TCP 22 da rede da universidade. Sem isso, o túnel não alcança as EC2.
- [ ] Confirmar acesso ao console AWS/Instance Connect para a inspeção remota, ou um SSH existente.
- [ ] Criar A e B conforme `00-PREPARACAO.md`, ambas com 4 GiB e endereços privados estáveis durante o ensaio.
- [ ] Aplicar Security Group restrito à turma e ao próprio grupo para os bancos.
- [ ] Instalar Docker nas EC2 e transferir a pasta `infra`.
- [ ] Gerar `.env` e chave interna somente em A; transferir os mesmos arquivos para B.
- [ ] Conferir a impressão digital ED25519 dos dois servidores pelo console AWS.
- [ ] Verificar sincronização de relógio (`timedatectl status`) em A e B.
- [ ] Baixar as imagens antes da aula para não depender do tempo de download durante os experimentos.
- [ ] Definir pares de EC2 por aluno e orçamento/encerramento dos recursos.

Pré-download, em A e B, dentro de `infra`:

```bash
set -a
source .env
set +a
sudo docker pull "$PG_IMAGE"
sudo docker pull "$CITUS_IMAGE"
sudo docker pull "$MONGO_IMAGE"
```

Para entregar infraestrutura por download remoto, publique apenas `infra-publica.tar.gz`, que exclui segredos. Não publique a pasta que você configurou com credenciais. O pacote de alunos também não contém credenciais de um ensaio.

## 2. Sequência recomendada

Planeje três encontros práticos, ou um bloco de preparação mais três sessões de experimentos. Os tempos dos roteiros pressupõem que acesso AWS e transferência dos arquivos já funcionam.

Primeiro, retome a aplicação balanceada das aulas anteriores: os servidores podem receber requisições semelhantes e mesmo assim enxergar estados diferentes. Em seguida, apresente o contrato de cada ambiente:

1. Replicação: escrita em A; leitura em B, propositalmente atrasada.
2. Citus: acesso pelo coordenador; fragmentos nos dois workers.
3. MongoDB: acesso pelo mongos; duas faixas de documentos em dois shards.

Peça sempre uma previsão antes de executar. Depois confronte a aplicação com os terminais das EC2. A conclusão precisa vir da observação, não de um desenho ou rótulo da aplicação.

## 3. Ensaio da etapa 1

Execute o roteiro do aluno sem pular comandos. Deixe A e B em janelas lado a lado, ambas em `~/lab-bancos/infra`.

Verificações obrigatórias:

- [ ] `pg-a` em A e `pg-b` em B iniciam sem erro.
- [ ] A mostra `pg_is_in_recovery=false`; B mostra `true` e atraso de 15 s.
- [ ] A mostra uma conexão `streaming`, `async`.
- [ ] Cliente Windows conecta às duas máquinas, sem instalar nada.
- [ ] Cliente Linux conecta às duas máquinas, sem instalar nada.
- [ ] `POST` não existe neste cliente: a inserção usa o protocolo PostgreSQL. Reforce a diferença entre CRUD e HTTP.
- [ ] Cadastro é confirmado; uma leitura imediata pela réplica não encontra o registro.
- [ ] A consulta direta em A encontra o cadastro; B passa a encontrá-lo depois.
- [ ] UPDATE e DELETE produzem a janela de leitura antiga.
- [ ] Escrita direta na réplica é recusada.
- [ ] Parar B mantém escrita em A e faz leitura em B falhar; reiniciar e reconectar recupera.

Use matrículas diferentes para repetição: `100001`, `100002`, etc. Cronometre a partir do commit confirmado. Se você leva 20 segundos para trocar de terminal, não observará o intervalo: deixe as consultas prontas ou aumente o atraso.

Para aumentar o atraso para 30 s, em B, edite `lab.sh` e altere o argumento `-c recovery_min_apply_delay=15s` para `30s` no bloco `pg-b`. Depois execute, **somente em B**:

```bash
bash lab.sh parar pg
bash lab.sh pg-b
bash lab.sh inspecionar-pg-b
```

O volume permanece. Reconecte o cliente e confira `SHOW recovery_min_apply_delay`. O argumento de linha de comando tem prioridade sobre `ALTER SYSTEM`; por isso a mudança é feita no comando que inicia o processo.

Para o ensaio normal, mantenha 15 s. Não configure `synchronous_commit=remote_apply` esperando confirmação rápida: com espera síncrona de aplicação, o atraso passa a bloquear commits.

## 4. Ensaio da etapa 2

Pare a etapa 1 nas duas EC2. Execute `citus-a`, `citus-b` e depois `citus-init` em A.

- [ ] Os dois workers aparecem no coordenador.
- [ ] `citus_shards` mostra quatro fragmentos, com posições nos dois workers.
- [ ] A carga de 20 exemplos é inserida pelo usuário `lab`.
- [ ] A listagem lógica tem 20 registros antes das alterações.
- [ ] A inspeção física encontra registros em ambos os workers; a soma é 20.
- [ ] A opção de localização identifica corretamente o worker de uma matrícula conhecida.
- [ ] UPDATE e DELETE alteram o fragmento físico correto.
- [ ] Parar B afeta uma busca direcionada a B e a listagem global; a busca direcionada a A pode continuar.
- [ ] Parar/recriar os contêineres, preservando volumes, mantém a configuração funcional sem repetir `citus-init`.

Não exija dez registros por worker: a função hash não garante equilíbrio exato num conjunto tão pequeno. Não confunda o número de fragmentos com o número de máquinas.

O nome `EC2_A_COORDENADOR` na aplicação identifica o servidor ao qual o cliente está conectado. Mostre a posição física no catálogo e abra os fragmentos nos workers para completar a evidência.

## 5. Ensaio da etapa 3

Pare os processos Citus. Siga a ordem: `mongo-a`, `mongo-b`, `mongo-init-a`, `mongo-init-b`, `mongo-router`, `mongo-init`.

- [ ] Config server e shards têm primário e nomes esperados.
- [ ] Roteador responde `isdbgrid`.
- [ ] `sh.status()` mostra os dois shards e o corte no inteiro 500000.
- [ ] Aplicação autentica como `lab` em `labdb` e lista 20 exemplos.
- [ ] Shard A tem as dez matrículas baixas; B tem as dez altas.
- [ ] A busca por matrícula no explain mostra a seleção de shard.
- [ ] A consulta sem chave exige consultar mais shards.
- [ ] UPDATE/DELETE e falha parcial apresentam o resultado esperado.
- [ ] Parar/recriar com volumes preservados não exige recriar usuários, replica sets ou chunks.

O balanceador foi parado antes da inserção para manter posições previsíveis. Isso é uma decisão de demonstração. A facilidade de configuração deve ser discutida pelos componentes e comandos efetivamente usados, não atribuída genericamente a “NoSQL”.

## 6. Diagnóstico por camada

**Aplicativo não abre:** confira arquitetura x86_64, permissões da pasta, extração completa e política institucional. No Linux, dê permissão de execução. No Windows, abra pelo PowerShell para conservar a mensagem de erro. Não é preciso instalar Rust.

**Timeout SSH:** confira IP público atual, instância ligada, porta 22 no Security Group e saída da rede local. O IP público pode mudar depois de parar/iniciar a EC2.

**Fingerprint diferente:** obtenha novamente a impressão digital pelo console AWS. Não ignore o erro nem use a impressão digital da chave do aluno.

**Falha de autenticação SSH:** usuário Ubuntu é `ubuntu`; verifique se a EC2 foi criada com a chave selecionada. O cliente aceita uma chave comum para A e B, como pede a preparação.

**Túnel abre, banco não conecta:** confira etapa, porta, processo ativo e logs. No cliente use 5432/5433, 5540 ou 27017, conforme etapa.

```bash
bash lab.sh status
sudo docker logs --tail 80 NOME_DO_CONTAINER
sudo docker stats --no-stream
```

**Réplica não sobe:** consulte os logs de B; confira IP privado de A, senha, grupo de segurança, `pg_hba.conf` e ausência de restos de um basebackup interrompido. Não apague um volume antes de saber se contém dados que deseja preservar.

**Citus não alcança worker:** confira IP e porta no catálogo, grupo de segurança e `PGPASSFILE`. O pacote mantém o arquivo de senha em volume persistente para sobreviver à recriação do contêiner.

**MongoDB não inicia:** confirme AVX/x86_64, memória, chave interna igual e permissões. Se a chave de A e B for diferente, a autenticação interna falhará. Não execute o bootstrap de usuários uma segunda vez.

**MongoDB mostra tudo em um shard:** verifique se o acesso é pelo mongos, se a coleção está fragmentada, se existe o corte e se o intervalo alto foi movido. Alguns poucos inserts, sozinhos, não demonstram balanceamento automático.

**Memória insuficiente:** confira se só uma etapa está ligada. Não execute compilação Rust nas EC2 de aula; os binários são preparados antes. Os limites dos contêineres ajudam a conter uso, mas precisam ser observados sob a carga real.

## 7. Reinício e repetição limpa

Os comandos `parar` removem contêineres, mas preservam dados. Isso permite repetir consultas e reiniciar serviços. A carga de exemplo não sobrescreve matrículas existentes; duplicatas serão reportadas.

Para um ensaio inteiramente novo, prefira criar um par novo ou remover **somente os volumes do laboratório**, depois de confirmar que os dados são descartáveis. Com os contêineres parados, nomes por etapa:

- PostgreSQL: `lab-pg-a-data`, `lab-pg-b-data`.
- Citus: `lab-citus-coord-data`, `lab-citus-wa-data`, `lab-citus-wb-data`.
- MongoDB: `lab-mongo-config-data`, `lab-mongo-sa-data`, `lab-mongo-sb-data`.

Em cada máquina remova apenas os volumes presentes ali, com `sudo docker volume rm NOME`. Isso apaga os registros daquela etapa. Não use `docker system prune --volumes` em máquinas compartilhadas. Mantenha `.env` e a chave interna coerentes com os volumes; alterar a senha no arquivo não muda usuários já inicializados.

## 8. Avaliação sugerida

Avalie configuração reproduzível (3 pontos), evidência da localização/origem dos dados (3), explicação de atraso/falha (3) e clareza do registro (1). Screenshots sem identificação do nó ou sem interpretação não comprovam o objetivo.

Perguntas de fechamento:

- Como provar que um cadastro foi confirmado, mesmo sem aparecer na leitura seguinte?
- O que precisamos adicionar para tolerar perda de um worker ou shard?
- Qual consulta exige comunicação com mais de um nó e por quê?
- Qual parte da localização é decidida pela aplicação e qual pelo banco?

A ponte para a aula seguinte é discutir garantias de consistência, quóruns e recuperação, a partir das falhas observadas.

## 9. Encerramento AWS

Pare os serviços, confira as entregas e interrompa ou encerre as EC2 conforme o planejamento. Verifique volumes EBS, snapshots e endereços públicos/Elastic IP que possam permanecer cobrados. Interromper o processo Docker não encerra a cobrança da instância.
