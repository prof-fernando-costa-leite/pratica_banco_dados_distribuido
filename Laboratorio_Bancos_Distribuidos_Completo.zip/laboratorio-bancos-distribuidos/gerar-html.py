#!/usr/bin/env python3
"""Gera cópias HTML offline dos roteiros; requer markdown no computador de autoria."""
from pathlib import Path
import re
import markdown
root=Path(__file__).resolve().parent
css='''body{font:17px/1.65 system-ui,sans-serif;color:#182b3b;max-width:920px;margin:48px auto;padding:0 28px}h1{font-size:32px;line-height:1.25;border-bottom:4px solid #167a85;padding-bottom:18px}h2{font-size:24px;margin-top:36px}h3{font-size:20px}a{color:#07667a}pre{background:#f0f4f6;border-left:4px solid #167a85;padding:16px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px;line-height:1.5}code{font-family:ui-monospace,Consolas,monospace}li{margin:7px 0}nav{font-size:14px;color:#536675}blockquote{border-left:4px solid #c9d6dd;padding-left:18px}@media print{body{font-size:11pt;margin:0;max-width:none;padding:0}h1{font-size:24pt}h2{font-size:17pt;break-after:avoid}pre{font-size:9pt}nav{display:none}a{color:inherit;text-decoration:none}@page{size:A4;margin:18mm}}'''
for path in sorted((root/'docs').glob('*.md')):
    body=markdown.markdown(path.read_text(),extensions=['fenced_code','tables'])
    body=re.sub(r'href="([^"#:]+)\.md(#[^"]*)?"',lambda m:'href="'+m[1]+'.html'+(m[2] or '')+'"',body)
    title=path.read_text().splitlines()[0].removeprefix('# ')
    page=f'<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>{css}</style><nav>Laboratório de Bancos Distribuídos · <a href="../INICIO.html">Início</a> · Ctrl+P para imprimir/salvar em PDF</nav><main>{body}</main></html>'
    path.with_suffix('.html').write_text(page)
links=''.join(f'<li><a href="docs/{p.stem}.html">{p.read_text().splitlines()[0].removeprefix("# ")}</a></li>' for p in sorted((root/'docs').glob('*.md')))
(root/'INICIO.html').write_text(f'<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Laboratório de Bancos Distribuídos</title><style>{css}</style><h1>Laboratório de Bancos Distribuídos</h1><p>Três etapas · duas EC2 · cliente local Rust</p><p>Comece pela preparação. Cada roteiro contém configuração, experimentos e inspeção dos registros diretamente nos nós. Os executáveis Windows e Linux estão na pasta <code>dist</code>.</p><ul>{links}</ul><p>Estas páginas funcionam offline. Use Ctrl+P para imprimir ou salvar em PDF.</p></html>')
