#!/usr/bin/env python3
"""Falhas controladas somente nos contêineres locais lab-* criados para validação."""
import subprocess

def run(args, text=None):
    return subprocess.run(args,input=text,text=True,capture_output=True,timeout=45)

def pg(sql):
    return run(['docker','exec','-i','lab-citus-coord','psql','-X','-qAt','-v','ON_ERROR_STOP=1','-U','postgres','-d','labdb','-p','5540'],"SET statement_timeout='5s';\n"+sql)

def mongo(id=None):
    query='{}' if id is None else "{matricula:Long('"+str(id)+"')}"
    js="db.getSiblingDB('admin').auth(process.env.MONGO_USER,process.env.MONGO_PASSWORD);print(db.getSiblingDB('labdb').alunos.find("+query+").maxTimeMS(4000).toArray().length);"
    return run(['docker','exec','lab-mongo-router','mongosh','--quiet','--port','27017','--eval',js])

mapping=pg("WITH ids AS (SELECT generate_series(100001,100010)::bigint AS id) SELECT id,nodeport FROM ids JOIN citus_shards s ON s.shardid=get_shard_id_for_distribution_column('alunos',id) WHERE table_name='alunos'::regclass;")
assert mapping.returncode==0,mapping.stderr
ids={}
for row in mapping.stdout.strip().splitlines():
    id,port=map(int,row.split('|'));ids.setdefault(port,id)
assert 5541 in ids and 5542 in ids,ids
try:
    assert run(['docker','stop','-t','3','lab-citus-wb']).returncode==0
    a=pg(f'SELECT matricula FROM alunos WHERE matricula={ids[5541]};')
    b=pg(f'SELECT matricula FROM alunos WHERE matricula={ids[5542]};')
    all_rows=pg('SELECT count(*) FROM alunos;')
    assert a.returncode==0 and str(ids[5541]) in a.stdout,a.stderr
    assert b.returncode!=0 and all_rows.returncode!=0,(b,all_rows)
    print('Citus com B parado: leitura em A funciona; leitura em B e global falham.')
finally:
    run(['docker','start','lab-citus-wb'])
try:
    assert run(['docker','stop','-t','3','lab-mongo-sb']).returncode==0
    a=mongo(100001);b=mongo(700001);all_rows=mongo()
    assert a.returncode==0 and a.stdout.strip().endswith('1'),a.stderr
    assert b.returncode!=0 and all_rows.returncode!=0,(b,all_rows)
    print('MongoDB com B parado: leitura em A funciona; leitura em B e global falham.')
finally:
    run(['docker','start','lab-mongo-sb'])
