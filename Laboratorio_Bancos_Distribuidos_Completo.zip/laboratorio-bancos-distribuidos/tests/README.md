# Validação técnica

Os testes de integração usam exclusivamente dados fictícios e a matrícula reservada `900000001`. O registro final está em `docs/VALIDACAO.md`.

`cargo test --locked` verifica a validação da matrícula e a preservação de tipos/Unicode na conversão BSON. O principal teste é a execução real do CRUD nas três topologias, pelo modo `--smoke` do cliente.

O fixture local executa os serviços nas portas distintas dos roteiros, com NODE_A e NODE_B iguais a 127.0.0.1. Isso permite testar todos os processos em um host Linux. Não simula latência entre EC2, domínios de falha, Security Groups ou o limite total de RAM de uma máquina de 4 GiB.

O Dockerfile SSH serve somente para testar autenticação por chave, validação do fingerprint e encaminhamento de conexões. Não distribua sua imagem como servidor de produção/aula. A senha de fixture não é aceita por SSH (`PasswordAuthentication no`), e a chave pública autorizada é injetada pelo teste.

Para reproduzir a infraestrutura, copie `infra` para um diretório temporário, rode `configurar.sh` com 127.0.0.1 nos dois campos e siga a mesma sequência dos roteiros. Antes, confirme que as portas e os nomes `lab-*` não estão em uso por outro trabalho. O pacote não executa limpeza global de Docker.

Para testar por SSH, configure o fixture em porta local 2222 e forneça as variáveis descritas em `docs/05-COMPILACAO.md`. Para ensaio real AWS, use o fluxo interativo do aplicativo com dois endereços públicos e fingerprints distintos.
