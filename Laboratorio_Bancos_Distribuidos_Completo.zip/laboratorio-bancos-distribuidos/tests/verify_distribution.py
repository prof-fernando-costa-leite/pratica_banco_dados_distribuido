#!/usr/bin/env python3
"""Executar somente no fixture Docker local de desenvolvimento, após inicializar as etapas."""
import subprocess

def run(args, text=None, check=True):
    return subprocess.run(args,input=text,text=True,capture_output=True,check=check,timeout=40)

def pg(name,port,sql):
    return run(['docker','exec','-i',name,'psql','-X','-qAt','-v','ON_ERROR_STOP=1','-U','postgres','-d','labdb','-p',str(port)],sql).stdout.strip()

def mongo(name,port,js):
    return run(['docker','exec','-i',name,'mongosh','--quiet','--port',str(port),'--eval',
        "db.getSiblingDB('admin').auth(process.env.MONGO_USER,process.env.MONGO_PASSWORD);"+js]).stdout.strip()

seed="""INSERT INTO alunos(matricula,nome,email,curso)
SELECT n,'Aluno '||n,'aluno'||n||'@example.test','SD'
FROM (SELECT generate_series(100001,100010) n UNION ALL SELECT generate_series(700001,700010)) s
ON CONFLICT (matricula) DO NOTHING;"""
pg('lab-citus-coord',5540,seed)
assert pg('lab-citus-coord',5540,'SELECT count(*) FROM alunos;')=='20'
counts=[]
for name,port in [('lab-citus-wa',5541),('lab-citus-wb',5542)]:
    out=pg(name,port,r"""SET citus.show_shards_for_app_name_prefixes='psql';
SELECT format('SELECT count(*) FROM %I.%I;',schemaname,tablename)
FROM pg_tables WHERE schemaname='public' AND tablename ~ '^alunos_[0-9]+$'
\gexec
""")
    counts.append(sum(int(n) for n in out.splitlines()))
assert sum(counts)==20 and all(n>0 for n in counts),counts
print(f'Citus: lógico=20; físicos A={counts[0]}, B={counts[1]}; união=20')

mongo('lab-mongo-router',27017,"""
const d=db.getSiblingDB('labdb');
for (const b of [100000,700000]) for(let i=1;i<=10;i++) {
  const n=Long(String(b+i));
  d.alunos.updateOne({matricula:n},{$setOnInsert:{matricula:n,nome:'Aluno '+n,email:'aluno'+n+'@example.test',curso:'SD'}},{upsert:true});
}
print(d.alunos.countDocuments({}));
""")
for name,port,expected in [('lab-mongo-router',27017,20),('lab-mongo-sa',27018,10),('lab-mongo-sb',27020,10)]:
    n=mongo(name,port,"print(db.getSiblingDB('labdb').alunos.countDocuments({}));").splitlines()[-1]
    assert int(n)==expected,(name,n)
print('MongoDB: lógico=20; físicos A=10, B=10; união=20')

result=run(['docker','exec','-i','lab-pg-b','psql','-X','-v','ON_ERROR_STOP=1','-U','postgres','-d','labdb','-p','5433'],"INSERT INTO alunos VALUES(123456,'Teste','teste@example.test','SD');",check=False)
assert result.returncode != 0 and 'read-only' in result.stderr,result
print('PostgreSQL: escrita na réplica recusada')
